# VS-000 — Backend Membership Commerce Tracer

## Status
READY_FOR_REVIEW_CLEAN

## Resources involved
- `User`
- `UserProfile`
- `ConsentRecord`
- `AccountRole`
- `MembershipProduct`
- `MembershipPlan`
- `Membership`
- `BenefitRule`
- `EntitlementGrant`
- `Offer`
- `Price`
- `Order`
- `OrderItem`
- `Payment`
- `PaymentMethod`
- `PaymentEvent`

## Actions involved
- `Accounts.register_user`
- `Accounts.confirm_email`
- `Accounts.bootstrap_staff_admin`
- `Memberships.create_membership_product`
- `Memberships.activate_membership_product`
- `Memberships.create_membership_plan`
- `Memberships.create_benefit_rule`
- `Memberships.activate_benefit_rule`
- `Memberships.activate_membership_plan`
- `Catalog.create_membership_offer`
- `Catalog.create_membership_price`
- `Catalog.activate_membership_price`
- `Catalog.activate_membership_offer`
- `Commerce.create_pending_order`
- `Commerce.add_membership_order_item`
- `Commerce.initialize_paystack_transaction`
- `Commerce.submit_order_for_payment`
- `Commerce.ingest_paystack_webhook`
- `Commerce.record_payment_event`
- `Commerce.mark_payment_succeeded`
- `Commerce.mark_order_paid`
- `Commerce.move_payment_to_review`
- `Commerce.fulfil_paid_order`
- `Commerce.record_payment_method`
- `Commerce.verify_paystack_transaction`
- `Memberships.create_pending_membership`
- `Memberships.activate_membership`
- `Memberships.create_entitlement_grants`
- `Memberships.evaluate_entitlement_access`

## Blocking decisions
- none

## Required tests
- `backend_tracer_proves_full_membership_commerce_spine`
- `paystack_callback_does_not_activate_membership`
- `duplicate_success_event_does_not_duplicate_success_effects`
- `access_evaluation_does_not_mutate_state`
- `stores_paystack_authorization_metadata_without_raw_card_data`
- `duplicate_fulfilment_does_not_duplicate_membership_or_grants`
- `webhook_success_confirms_provisional_fulfilment`
- `callback_verify_success_can_provisionally_fulfil_order`

## Slice law
The tracer SHALL prove the backend commercial spine before UI expansion:

confirmed user -> configured membership product/plan/offer/price -> pending order -> Paystack Verify or webhook success fixture -> single fulfilment pipeline -> paid/fulfilled order -> active membership -> entitlement grants -> access true.

The tracer SHALL NOT implement recurring billing, discount calculation, CMS content, events, learning, physical products, refunds, or admin UI.


The tracer SHALL prove that webhook success and callback Verify success both use `Commerce.fulfil_paid_order` and do not create duplicate memberships or grants.
