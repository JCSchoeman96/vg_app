# 08. Slice Matrix

| Slice | Name | Status | Primary goal |
|---|---|---|---|
| VS-000 | Backend membership commerce tracer | READY_FOR_REVIEW_CLEAN | Prove the full backend commercial spine |
| VS-001A | Register user with AshAuthentication and consent | READY_FOR_REVIEW_CLEAN | Create confirmed-capable account foundation |
| VS-001B | Login/session/password reset/staff role foundation | READY_FOR_REVIEW_CLEAN | Make actors real and testable |
| VS-002A | Configure membership product, plans, benefits, offer, prices | READY_FOR_REVIEW_CLEAN | Seed/configure Vriendinneklub without hardcoding |
| VS-002B | Create pending membership order | READY_FOR_REVIEW_CLEAN | Confirmed user creates order and pending membership |
| VS-002C | Paystack payment confirmation | READY_FOR_REVIEW_CLEAN | Initialize Paystack, ingest verified success idempotently |
| VS-002D | Activate membership and grants | READY_FOR_REVIEW_CLEAN | Fulfil paid order atomically |
| VS-002E | Evaluate member access | READY_FOR_REVIEW_CLEAN | Read-only defensive access check |
| VS-003A | Minimal expandable LiveView pages | READY_FOR_REVIEW_CLEAN | Thin pages after backend proof |

READY_FOR_REVIEW_CLEAN does not authorize coding.
