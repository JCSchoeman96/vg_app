# Voelgoed Ash Agent Pack v0.2.7

This planning pack is a review-clean, not coding-ready, baseline for the VG App membership commerce foundation.

## What changed in v0.2.7

- Locked UUIDv7 primary keys across the platform.
- Locked UTC microsecond persisted timestamps.
- Locked UUIDv7 sorting as secondary technical ordering only.
- Added active `PaymentMethod` resource for safe Paystack authorization metadata.
- Added deferred `Subscription` resource card only.
- Added `renewal_mode`, `public_sale_state`, and recurring capability gates to `MembershipPlan`.
- Added `payment_review` states for payment contradiction handling.
- Hardened Paystack callback Verify vs webhook authority law.
- Added one idempotent `Commerce.fulfil_paid_order` action for both webhook and Verify success.
- Added raw Paystack payload restricted storage plus hash requirements.

## Important status

`coding_status: NOT_READY`

The validator passes, but every slice still requires a slice-specific `/grill-me` before it may be marked `READY_FOR_CODING`.
