# vg_app Repo Automation Pack

This pack contains hardened repository automation for the `vg_app` project.

## Install

Copy these files into the repo root:

```text
Makefile
scripts/install_git_hooks.sh
scripts/check_repo_state.sh
scripts/sync_with_origin_main.sh
scripts/dev_postgres.sh
scripts/precommit.sh
scripts/create_pr.sh
.githooks/pre-commit
```

Then run:

```bash
chmod +x scripts/*.sh .githooks/pre-commit
make hooks
make doctor
```

## Core workflow

```text
make status
|> make sync-check
|> make setup
|> make precommit
|> make pr
```

## Database defaults

```text
container: vg_app-postgres-dev
volume:    vg_app-postgres-dev-data
database:  vg_app_dev
host port: 5433
```

Override the host port when needed:

```bash
VG_APP_POSTGRES_HOST_PORT=5434 make infra
```

## Precommit command overrides

The precommit script runs a full local gate and allows command overrides:

```bash
ASH_CODEGEN_CHECK_CMD="mise exec -- mix project.codegen_check" make precommit
SOBELOW_CMD="mise exec -- mix sobelow" make precommit
```

Use overrides only to point at project-owned wrapper tasks. Do not weaken the gate to make tests green.
