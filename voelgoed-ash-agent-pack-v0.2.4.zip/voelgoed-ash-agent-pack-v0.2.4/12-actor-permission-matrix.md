# 12. Actor Permission Matrix

## v0.2 actors
Only these actors exist in v0.2 planning:

- `public_visitor`
- `registered_user`
- `staff_admin`
- `system`

A coding agent MUST NOT add actor types for v0.2.

## Permission matrix

| Action | public_visitor | registered_user | staff_admin | system |
|---|---:|---:|---:|---:|
| `Accounts.register_user` | Allow | Deny | Deny | Deny |
| `Memberships.create_membership_plan` | Deny | Deny | Allow | Deny |
| `Memberships.activate_membership_plan` | Deny | Deny | Allow | Deny |
| `Memberships.create_benefit_rule` | Deny | Deny | Allow | Deny |
| `Memberships.activate_benefit_rule` | Deny | Deny | Allow | Deny |
| `Catalog.create_vriendinneklub_offer` | Deny | Deny | Allow | Deny |
| `Catalog.create_vriendinneklub_price` | Deny | Deny | Allow | Deny |
| `Catalog.activate_vriendinneklub_price` | Deny | Deny | Allow | Deny |
| `Catalog.activate_vriendinneklub_offer` | Deny | Deny | Allow | Deny |
| `Catalog.snapshot_price_for_order_item` | Deny | Deny | Deny | Allow through Commerce action only |
| `Commerce.create_pending_order` | Deny | Allow own user only | Deny | Deny |
| `Commerce.add_vriendinneklub_order_item` | Deny | Allow own order only | Deny | Deny |
| `Commerce.submit_order_for_payment` | Deny | Allow own order only | Deny | Deny |
| `Commerce.record_payment_event` | Deny | Deny | Deny | Allow |
| `Commerce.mark_payment_succeeded` | Deny | Deny | Deny | Allow |
| `Commerce.mark_order_paid` | Deny | Deny | Deny | Allow |
| `Memberships.create_pending_membership` | Deny | Deny | Deny | Allow through join flow only |
| `Memberships.activate_membership` | Deny | Deny | Deny | Allow |
| `Memberships.create_entitlement_grants` | Deny | Deny | Deny | Allow through activation only |
| `Memberships.evaluate_entitlement_access` | Deny | Deny | Deny | Allow through application boundary only |

## Actor invariants
- `public_visitor` MUST NOT create orders or memberships.
- `registered_user` MUST NOT mark payment or order state as paid.
- `staff_admin` MUST NOT activate user memberships in v0.2 unless D-012 creates a separate audited action.
- `system` MUST NOT create offers, prices, plans, or benefit rules in v0.2 unless VS-002A explicitly chooses system seeding and updates this matrix.


---

## v0.2.4 actor clarification

VS-002A production actor SHALL be `staff_admin`.

System seeding MAY be used only as test fixture setup.

System seeding MUST NOT be represented as a production action in v0.2.
