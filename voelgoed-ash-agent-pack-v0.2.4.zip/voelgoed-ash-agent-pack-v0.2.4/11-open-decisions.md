# 11. Open Decisions

## v0.2.4 decision status
This file separates locked decisions from still-open future decisions.

A coding agent MUST NOT treat a locked decision as permission to implement. A locked decision only removes ambiguity for the affected slice.

## v0.2 locked decisions

| ID | Decision | Locked value | Applies to |
|---|---|---|---|
| D-002 | Entitlement shape | VG App v0.2 SHALL use `BenefitRule` + `EntitlementGrant` + `Memberships.evaluate_entitlement_access`. A generic `Entitlement` resource MUST NOT be introduced. `BenefitRule` SHALL define what a `MembershipPlan` grants. `EntitlementGrant` SHALL be the persisted grant created from `BenefitRule` after membership activation. `Memberships.evaluate_entitlement_access` SHALL be read-side access evaluation and MUST NOT mutate state. | VS-002A, VS-002D, VS-002E |
| D-005 | Refund reversal implications | Full refund implementation SHALL remain deferred in v0.2. v0.2 resources MUST preserve `source_order_id`, `source_membership_id`, and `source_benefit_rule_id` where needed for future reversal. Future refund reversal MUST be able to revoke, expire, or supersede `EntitlementGrant` records deterministically. v0.2 MUST NOT implement refund actions. | VS-002B, VS-002D |
| D-009 | Payment model for v0.2 | v0.2 SHALL use simulated/manual trusted payment confirmation through a system-only `PaymentEvent`. Provider-specific gateway implementation SHALL be deferred. The event model MUST remain compatible with future provider webhook ingestion. Payment return/cancel SHALL be read-only. Payment success MUST be represented by a trusted `PaymentEvent`. Payment code MUST NOT create Membership or EntitlementGrant records directly. | VS-002B, VS-002C |
| D-010 | OrderItem snapshot rule | `OrderItem` SHALL snapshot `offer_id`, `price_id`, `membership_plan_id`, `quantity`, `unit_amount_minor`, `line_total_minor`, `currency`, and `snapshot_at`. `OrderItem` MUST NOT depend on product variant, inventory, shipping, tax, coupon, or cart-first checkout fields in v0.2. | VS-002B |
| D-011 | PaymentEvent idempotency key | `PaymentEvent` SHALL own idempotency. `PaymentEvent.idempotency_key` SHALL be unique. When `provider_event_id` exists, it SHALL be the idempotency source. For simulated/manual v0.2 payments, the key SHALL be deterministic from `order_id + payment_reference + amount_minor + currency`. Payment return/cancel SHALL be read-only. Membership activation SHALL occur only after a trusted `PaymentEvent` is processed. Payment code MUST NOT create `EntitlementGrant` records directly. | VS-002C, VS-002D |
| D-012 | Manual admin activation | Manual admin activation SHALL be excluded from v0.2. No `staff_admin` action SHALL activate a user membership in v0.2. Membership activation SHALL occur only from the paid-order path. Manual activation MAY be reconsidered in a later slice with audit rules. | VS-002D |
| D-013 | Account creation during join flow | Registration SHALL complete before checkout in v0.2. Embedded registration during checkout SHALL be deferred. VS-001A SHALL create the registered user. VS-002B SHALL require a registered user actor. | VS-001A, VS-002B |
| D-014 | Pending Vriendinneklub order reuse policy | A registered user SHALL have at most one active pending Vriendinneklub join order per MembershipPlan. If a pending order exists with no succeeded payment and no active membership, the system SHALL reuse it. If a paid order or active membership already exists, duplicate join attempts SHALL be rejected deterministically. Expired or cancelled pending orders SHALL NOT be reused. | VS-002B |
| D-015 | Activation dispatch boundary | `Commerce.mark_order_paid` SHALL complete before membership activation. Membership activation SHALL run through `Memberships.activate_membership`. Entitlement grants SHALL be created through `Memberships.create_entitlement_grants`. `PaymentEvent` and Payment code MUST NOT create `EntitlementGrant` records directly. For v0.2 tests, synchronous after-success orchestration is allowed. Production/provider workflows MAY later move this boundary to Oban, but Oban is not required for v0.2. | VS-002C, VS-002D |
| D-016 | Root namespace / OTP app | Product/human name: VG App. GitHub repo: `vg_app`. Root module: `VGApp`. Web module: `VGAppWeb`. OTP app atom: `:vg_app`. App folder: `vg_app`. Main lib path: `lib/vg_app`. Web lib path: `lib/vg_app_web`. Repo: `VGApp.Repo`. Endpoint: `VGAppWeb.Endpoint`. No planning file may keep legacy placeholder namespaces after D-016 is locked. | All v0.2 slices |
| D-017 | Store_Blueprint extraction authority | Store_Blueprint SHALL be a reference/extraction source only. Store_Blueprint MUST NOT be used as the implementation baseline. No Store_Blueprint module SHALL be copied until it has a focused `KEEP / RENAME / REWRITE / REJECT` extraction decision. | All v0.2 slices |
| D-018 | Payment failure model | Failed payment SHALL be recorded on Payment and PaymentEvent. Order SHALL remain `pending_payment` after failed payment until retry, expiry, or cancellation. `Order.failed` SHALL NOT be used in v0.2. Failed payment MUST NOT activate membership. Failed payment MUST NOT create `EntitlementGrant` records. | VS-002C |
| D-020 | Vriendinneklub offer/price creation actor | VS-002A SHALL be `staff_admin` only in the production planning model. System seeding MAY be used only as test fixture setup. System seeding MUST NOT be represented as a production action in v0.2. | VS-002A |
| D-021 | v0.2 audit evidence | `AuditEvent` resource SHALL remain deferred in v0.2. v0.2 audit evidence SHALL be satisfied by database timestamps, state fields, source references, and test-proven traceability. High-risk actions MUST record source references where needed. Payment success, order paid, membership activation, and entitlement grant creation MUST be traceable through persisted records. | All v0.2 slices |

## v0.2 blocking decisions

There are no open v0.2 blocking decisions after v0.2.4 cleanup.

Slices may be `READY_FOR_REVIEW`, but no slice SHALL be `READY_FOR_CODING` until the planning validator exists and passes.

## v0.2 locked deferrals

| ID | Deferred item | Binding v0.2 rule |
|---|---|---|
| DEF-001 | Events | Events SHALL NOT be implemented in v0.2. |
| DEF-002 | Learning | Learning SHALL NOT be implemented in v0.2. |
| DEF-003 | Competitions | Competitions SHALL NOT be implemented in v0.2. |
| DEF-004 | Media | Media SHALL NOT be implemented in v0.2. |
| DEF-005 | Community | Community SHALL NOT be implemented in v0.2. |
| DEF-006 | Bundles | Bundles SHALL NOT be implemented in v0.2. |
| DEF-007 | Coupon stacking | Coupon stacking SHALL NOT be implemented in v0.2. |
| DEF-008 | Full refunds | Full refund implementation SHALL NOT be implemented in v0.2. |
| DEF-009 | AuditEvent resource | AuditEvent resource SHALL remain deferred; audit evidence is satisfied by persisted timestamps, state fields, source references, and tests. |
| DEF-010 | FulfilmentDispatch resource | Membership activation SHALL be explicit action flow for v0.2; `FulfilmentDispatch` resource is not required. |
| DEF-011 | Shipping | Shipping SHALL NOT be implemented in v0.2. |
| DEF-012 | Tax engine | Full tax engine implementation SHALL NOT be implemented in v0.2. |
| DEF-013 | Product variants / inventory | Product variants and inventory SHALL NOT be implemented in v0.2. |
| DEF-014 | Cart-first checkout | Cart-first checkout SHALL NOT be implemented in v0.2. |
| DEF-015 | Digital downloads | Digital downloads SHALL NOT be implemented in v0.2. |
| DEF-016 | Subscriptions implementation | Subscriptions SHALL NOT be implemented in v0.2. |

## Historical decisions moved out of v0.2
The following decisions are future-domain concerns and MUST NOT drive v0.2 implementation:

- Media boundary
- Shared categorisation strategy
- Discount application order beyond v0.2 no-discount rule
- Competition anti-fraud level
- Grace period policy unless recurring billing is included later
- Organiser portal scope
