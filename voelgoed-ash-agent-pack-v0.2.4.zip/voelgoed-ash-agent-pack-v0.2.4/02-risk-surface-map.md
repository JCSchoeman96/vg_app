# 02. Risk Surface Map

## Active v0.2 risks

| Area | Risk | Severity | Binding v0.2 response |
|---|---|---:|---|
| Account registration | Duplicate or invalid user identity | High | `Accounts.register_user` MUST enforce unique email. |
| Membership purchase | Active membership without paid order | High | `Memberships.activate_membership` MUST require `Order.state == paid`. |
| Payment event handling | Duplicate payment event creates duplicate activation | High | `PaymentEvent` MUST have a deterministic idempotency key. |
| Price correctness | Historical orders use mutable live price | High | `OrderItem` MUST snapshot price at creation. |
| Benefit definition | Membership grants are unclear | High | `BenefitRule` MUST define what the membership plan grants. |
| Entitlement grant | Access is granted without traceable source | High | `EntitlementGrant` MUST reference source membership and source benefit rule. |
| Cross-domain effects | Payment code directly grants access | High | Payment actions MUST NOT create entitlement grants directly. |
| Refund future path | v0.2 blocks future reversal | High | Refund implementation is deferred, but reversal implications MUST be recorded as constraints. |
| Side effects | Email or external calls occur inside transactions | Medium | Side effects MUST be outside the database transaction boundary. |

## Deferred risks
The following risks SHALL remain documented but MUST NOT drive v0.2 implementation:

- event ticket issuance
- event check-in
- organiser-scoped tenancy
- course enrolment
- webinar replay access
- competition voting
- media workflows
- community features
- bundles
- coupon stacking
- full refund processing

## Non-binding guidance
AuditEvent and FulfilmentDispatch can be revisited after v0.2 if repeated audit/dispatch patterns appear. They MUST NOT be required for v0.2 readiness.
