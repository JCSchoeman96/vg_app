# 03. Workflow Inventory

## Active v0.2 workflows

| Workflow | Actor | Outcome | Candidate slice | Status |
|---|---|---|---|---|
| Register account | `public_visitor` | `User` exists in `active` state | VS-001A | NOT_READY |
| Create Vriendinneklub offer and price | `staff_admin` or `system` | Active membership offer has active price | VS-002A | NOT_READY |
| Create pending join order | `registered_user` | Pending order, order item snapshot, pending membership | VS-002B | NOT_READY |
| Record payment event | `system` | Payment event stored once and payment marked succeeded | VS-002C | NOT_READY |
| Activate membership and grants | `system` | Membership active and entitlement grants created exactly once | VS-002D | NOT_READY |
| Evaluate member access | `system` | Read-only decision returned from active grants | VS-002D | NOT_READY |

## v0.2 workflow rules
- A workflow MUST NOT become a slice until resources and actions are known.
- A slice MUST remain `NOT_READY` while any referenced resource/action/decision/test is incomplete.
- Payment workflows MUST be idempotent.
- Access evaluation MUST NOT mutate state.

## Deferred workflows
The following workflows are deferred and SHALL NOT appear in v0.2 slice packs:

| Workflow | Deferred reason |
|---|---|
| Access member-only content | Requires content gating beyond v0.2. |
| Buy product | Requires product fulfilment beyond v0.2. |
| Buy course | Requires learning/enrolment beyond v0.2. |
| Buy event ticket | Requires event/ticketing beyond v0.2. |
| Apply event discount | Requires event commerce and discount stacking decisions. |
| Check in ticket holder | Requires Admissions/Access device workflow. |
| Create organiser event | Requires organiser tenancy. |
| Publish organiser event | Requires event lifecycle. |
| Submit competition entry | Requires competition domain. |
| Vote in competition | Requires anti-fraud decisions. |
| Access webinar replay | Requires content/learning access scope. |


---

## v0.2.4 actor clarification

VS-002A production actor SHALL be `staff_admin`.

System seeding MAY be used only for test fixture setup.

System seeding MUST NOT be modelled as a production action in v0.2.
