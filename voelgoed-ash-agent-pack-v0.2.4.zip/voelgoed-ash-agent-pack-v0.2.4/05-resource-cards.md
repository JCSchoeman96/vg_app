# 05. Resource Cards

## Resource Card Standard
Every resource an agent is allowed to implement MUST use this structure.

```yaml-example
resource: Example
domain: ExampleDomain
purpose: What truth this resource owns
owns: []
does_not_own: []
state: []
source_of_truth: postgres
tenant_scope: global | user_scoped
ash_domain_module: VGApp.Domain
ash_resource_module: VGApp.Domain.Resource
relationships: []
identities: []
high_risk_invariants: []
actions_active_v0_2: []
actions_deferred: []
tests_required: []
open_decisions: []
```

## v0.2 resource boundary
Only the resource cards in this file are available to v0.2 slice packs.

A coding agent MUST NOT create resources outside this file for v0.2.

No Store_Blueprint module SHALL be copied from a resource card until the module has a focused `KEEP / RENAME / REWRITE / REJECT` extraction decision.

No resource card SHALL contain legacy placeholder namespaces after D-016 is locked.

---

## Resource: User

```yaml
resource: User
domain: Accounts
purpose: Represents a person who can authenticate and participate in the ecosystem.
owns:
  - account identity
  - authentication-linked user record
  - account lifecycle state
does_not_own:
  - membership lifecycle
  - order totals
  - payment state
  - benefit rules
  - entitlement grants
state:
  - active
  - suspended
source_of_truth: postgres
tenant_scope: global
ash_domain_module: VGApp.Accounts
ash_resource_module: VGApp.Accounts.User
relationships:
  - has_many memberships
  - has_many orders
identities:
  - unique_email
high_risk_invariants:
  - email must be unique
  - suspended users must not start protected v0.2 flows
actions_active_v0_2:
  - Accounts.register_user
actions_deferred: []
tests_required:
  - registers_user_with_unique_email
  - rejects_duplicate_email
  - suspended_user_cannot_start_join_flow
open_decisions: []
```

### Store_Blueprint reference notes

- Store Accounts MAY inform account/auth patterns.
- Store admin/support role assumptions MUST NOT be copied without actor-matrix approval.

---

## Resource: MembershipPlan

```yaml
resource: MembershipPlan
domain: Memberships
purpose: Defines the Vriendinneklub membership plan that can be purchased in v0.2.
owns:
  - plan identity
  - plan lifecycle state
  - link to benefit rules
does_not_own:
  - offer sellability
  - price amount
  - individual membership state
  - payment capture
state:
  - draft
  - active
  - archived
source_of_truth: postgres
tenant_scope: global
ash_domain_module: VGApp.Memberships
ash_resource_module: VGApp.Memberships.MembershipPlan
relationships:
  - has_many benefit_rules
  - has_many memberships
identities:
  - unique_plan_code
high_risk_invariants:
  - active plan must have at least one active benefit rule
  - archived plan must not be used for new membership purchase
actions_active_v0_2:
  - Memberships.create_membership_plan
  - Memberships.activate_membership_plan
actions_deferred:
  - Memberships.archive_membership_plan
tests_required:
  - active_plan_requires_benefit_rule
  - archived_plan_cannot_be_purchased
  - duplicate_plan_code_rejected
open_decisions: []
```

### Store_Blueprint reference notes

- Store subscriptions MAY inform future recurring behaviour only.
- Voelgoed v0.2 MembershipPlan SHALL NOT be replaced by Store SubscriptionPlan.
- SubscriptionPlan, RenewalAttempt, StoredPaymentMethod, and SubscriptionItem MUST NOT be inherited in v0.2.

---

## Resource: Membership

```yaml
resource: Membership
domain: Memberships
purpose: Tracks a user's Vriendinneklub lifecycle state.
owns:
  - membership lifecycle state
  - active/inactive membership status
  - activation source reference
does_not_own:
  - payment capture
  - order totals
  - offer pricing
  - notification delivery
state:
  - pending_payment
  - active
  - cancelled
  - expired
source_of_truth: postgres
tenant_scope: user_scoped
ash_domain_module: VGApp.Memberships
ash_resource_module: VGApp.Memberships.Membership
relationships:
  - belongs_to user
  - belongs_to membership_plan
  - belongs_to activation_order
  - has_many entitlement_grants
identities:
  - unique_active_or_pending_membership_per_user_plan
high_risk_invariants:
  - active membership must reference a paid order
  - manual admin activation is excluded from v0.2
  - pending_payment membership must not grant access
  - cancelled membership must not pass paid-benefit access checks
  - payment code must not mutate membership directly except through declared Memberships actions
actions_active_v0_2:
  - Memberships.create_pending_membership
  - Memberships.activate_membership
actions_deferred:
  - Memberships.cancel_membership
  - Memberships.expire_membership
tests_required:
  - pending_membership_does_not_grant_access
  - paid_order_activates_membership_once
  - cancelled_membership_blocks_access
  - duplicate_activation_does_not_duplicate_grants
open_decisions: []
```

### Store_Blueprint reference notes

- Store subscriptions MAY inform future recurring behaviour only.
- VG App v0.2 Membership SHALL be the active member status source.
- SubscriptionPlan, RenewalAttempt, StoredPaymentMethod, and SubscriptionItem MUST NOT be inherited in v0.2.

---

## Resource: BenefitRule

```yaml
resource: BenefitRule
domain: Memberships
purpose: Defines a specific benefit that an active Vriendinneklub membership plan can grant.
owns:
  - benefit type
  - benefit scope
  - benefit lifecycle state
  - rule metadata needed for access evaluation
does_not_own:
  - user-specific access state
  - payment state
  - order state
  - generic permission logic
state:
  - draft
  - active
  - archived
source_of_truth: postgres
tenant_scope: global
ash_domain_module: VGApp.Memberships
ash_resource_module: VGApp.Memberships.BenefitRule
relationships:
  - belongs_to membership_plan
  - has_many entitlement_grants
identities:
  - unique_rule_code_per_membership_plan
high_risk_invariants:
  - active benefit rule must belong to an active membership plan
  - archived benefit rule must not create new entitlement grants
  - benefit rule must declare an explicit benefit_type
  - BenefitRule must be the source rule used to create EntitlementGrant records
actions_active_v0_2:
  - Memberships.create_benefit_rule
  - Memberships.activate_benefit_rule
actions_deferred:
  - Memberships.archive_benefit_rule
tests_required:
  - active_benefit_rule_requires_active_plan
  - archived_benefit_rule_does_not_create_grants
  - benefit_rule_type_is_required
  - reject_duplicate_rule_code_per_plan
open_decisions: []
```

### Store_Blueprint reference notes

- BenefitRule SHALL be rewritten for VG App.
- BenefitRule MUST NOT be inferred from Store subscriptions.
- BenefitRule SHALL define what a MembershipPlan grants.

---

## Resource: EntitlementGrant

```yaml
resource: EntitlementGrant
domain: Memberships
purpose: Persisted grant created from an active BenefitRule after Membership activation.
owns:
  - user-specific access grant
  - grant status
  - grant validity window
  - source membership reference
  - source benefit rule reference
does_not_own:
  - rule definition
  - payment status
  - content/course/event access models
  - generic permission logic
state:
  - active
  - revoked
  - expired
source_of_truth: postgres
tenant_scope: user_scoped
ash_domain_module: VGApp.Memberships
ash_resource_module: VGApp.Memberships.EntitlementGrant
relationships:
  - belongs_to user
  - belongs_to membership
  - belongs_to benefit_rule
  - belongs_to source_order
identities:
  - unique_user_benefit_rule_membership_source
high_risk_invariants:
  - grant must reference a source BenefitRule
  - grant must reference a source Membership
  - duplicate activation must not duplicate grants
  - access evaluation must not mutate grant state
actions_active_v0_2:
  - Memberships.create_entitlement_grants
  - Memberships.evaluate_entitlement_access
actions_deferred:
  - Memberships.revoke_entitlement_grants
  - Memberships.expire_entitlement_grants
tests_required:
  - active_membership_creates_expected_grants_once
  - duplicate_grant_creation_is_idempotent
  - active_grant_allows_access
  - revoked_grant_denies_access
  - expired_grant_denies_access
  - wrong_user_grant_denied
  - access_evaluation_does_not_mutate_state
open_decisions: []
```

### Store_Blueprint reference notes

- Store EntitlementGrant MAY inform persisted grant shape.
- VG App EntitlementGrant SHALL be created from BenefitRule after membership activation.
- Subscription-only source assumptions MUST NOT be inherited.

---

## Resource: Offer

```yaml
resource: Offer
domain: Catalog
purpose: Sellable Vriendinneklub membership offer for v0.2 only.
owns:
  - offer code
  - offer lifecycle state
  - link to MembershipPlan
does_not_own:
  - product variants
  - inventory
  - cart state
  - payment state
state:
  - draft
  - active
  - archived
source_of_truth: postgres
tenant_scope: global
ash_domain_module: VGApp.Catalog
ash_resource_module: VGApp.Catalog.Offer
relationships:
  - belongs_to membership_plan
  - has_many prices
identities:
  - unique_offer_code
high_risk_invariants:
  - v0.2 offer_type must be vriendinneklub_membership
  - active offer must have exactly one active price
  - archived offer must not be purchased
actions_active_v0_2:
  - Catalog.create_vriendinneklub_offer
  - Catalog.activate_vriendinneklub_offer
actions_deferred:
  - Catalog.archive_vriendinneklub_offer
tests_required:
  - creates_vriendinneklub_offer_for_membership_plan
  - rejects_non_membership_offer_type_in_v0_2
  - active_offer_requires_one_active_price
  - rejects_duplicate_offer_code
open_decisions: []
```

### Store_Blueprint reference notes

- Store Catalog MUST NOT be inherited blindly.
- VG App v0.2 Offer SHALL support only Vriendinneklub membership purchase.
- Product, Variant, InventoryItem, ProductOption, and ProductImage MUST NOT be required.

---

## Resource: Price

```yaml
resource: Price
domain: Catalog
purpose: Active membership price that can be snapshotted into an OrderItem.
owns:
  - amount_minor
  - currency
  - billing_label
  - price lifecycle state
  - effective window metadata
does_not_own:
  - order item historical snapshot
  - coupons
  - promotions
  - tax
  - shipping
state:
  - draft
  - active
  - archived
source_of_truth: postgres
tenant_scope: global
ash_domain_module: VGApp.Catalog
ash_resource_module: VGApp.Catalog.Price
fields:
  amount_minor: integer
  currency: string
  billing_label: string
  effective_from_at: utc_datetime_usec | null
  effective_to_at: utc_datetime_usec | null
relationships:
  - belongs_to offer
identities:
  - one_active_price_per_offer
high_risk_invariants:
  - active price must use integer minor units
  - active price must have currency
  - only one active price may exist per offer in v0.2
actions_active_v0_2:
  - Catalog.create_vriendinneklub_price
  - Catalog.activate_vriendinneklub_price
  - Catalog.snapshot_price_for_order_item
actions_deferred:
  - Catalog.archive_vriendinneklub_price
tests_required:
  - creates_draft_price_for_vriendinneklub_offer
  - active_price_requires_positive_amount
  - activates_single_price_per_offer
  - rejects_second_active_price
  - snapshot_contains_amount_currency_and_price_source
  - snapshot_does_not_mutate_price
open_decisions: []
```

### Store_Blueprint reference notes

- Store Pricing MAY inform deterministic evaluation and snapshot discipline.
- VG App v0.2 Price SHALL support only one active Vriendinneklub membership price path.
- Coupons, promotions, shipping, tax, and eligibility engines MUST NOT be inherited in v0.2.

---

## Resource: Order

```yaml
resource: Order
domain: Commerce
purpose: Durable commercial record for the Vriendinneklub membership purchase.
owns:
  - order lifecycle state
  - order user ownership
  - order_ref
  - paid status
does_not_own:
  - payment event source truth
  - membership activation state
  - entitlement grants
  - shipping
  - tax
state:
  - pending_payment
  - paid
  - cancelled
  - expired
source_of_truth: postgres
tenant_scope: user_scoped
ash_domain_module: VGApp.Commerce
ash_resource_module: VGApp.Commerce.Order
relationships:
  - belongs_to user
  - has_many order_items
  - has_many payments
  - has_one membership
identities:
  - unique_order_ref
  - one_active_pending_vriendinneklub_order_per_user_plan
high_risk_invariants:
  - order must belong to a registered active user
  - order total must come from immutable OrderItem snapshots
  - order must not recalculate totals from live Price after payment
  - Order.failed SHALL NOT be used in v0.2
actions_active_v0_2:
  - Commerce.create_pending_order
  - Commerce.mark_order_paid
actions_deferred:
  - Commerce.cancel_order
  - Commerce.expire_order
tests_required:
  - active_user_can_create_pending_join_order
  - suspended_user_cannot_create_pending_join_order
  - submit_order_moves_order_to_pending_payment
  - succeeded_payment_marks_order_paid
  - duplicate_mark_order_paid_does_not_duplicate_activation
open_decisions: []
```

### Store_Blueprint reference notes

- Store.Orders MAY inform order lifecycle and order_ref patterns.
- VG App v0.2 SHALL use only minimal membership-purchase order behaviour.
- Inventory reservations, refund adjustments, shipping, tax, and cart-first checkout MUST NOT be inherited.

---

## Resource: OrderItem

```yaml
resource: OrderItem
domain: Commerce
purpose: Immutable line item snapshot for the Vriendinneklub membership offer purchased in an order.
owns:
  - offer_id snapshot
  - price_id snapshot
  - membership_plan_id snapshot
  - quantity
  - unit_amount_minor
  - line_total_minor
  - currency
  - snapshot_at
does_not_own:
  - live price amount
  - product variant
  - inventory
  - shipping
  - tax
state:
  - active
source_of_truth: postgres
tenant_scope: user_scoped
ash_domain_module: VGApp.Commerce
ash_resource_module: VGApp.Commerce.OrderItem
relationships:
  - belongs_to order
  - references offer snapshot
  - references price snapshot
  - references membership_plan snapshot
identities:
  - one_vriendinneklub_item_per_order
high_risk_invariants:
  - quantity must be 1 in v0.2
  - price snapshot must not mutate after creation
  - order item must not require product variant or inventory fields
actions_active_v0_2:
  - Commerce.add_vriendinneklub_order_item
actions_deferred: []
tests_required:
  - adds_vriendinneklub_item_with_price_snapshot
  - order_item_snapshots_price_at_creation
  - paid_order_item_snapshot_is_immutable
  - rejects_quantity_above_one_in_v0_2
  - rejects_duplicate_vriendinneklub_item_for_order
open_decisions: []
```

### Store_Blueprint reference notes

- Store OrderLineItem snapshot discipline MAY inform v0.2 snapshot rules.
- VG App OrderItem SHALL snapshot membership offer/price data only.
- Product variant, inventory, coupon, shipping, and tax fields MUST NOT be required in v0.2.

---

## Resource: Payment

```yaml
resource: Payment
domain: Commerce
purpose: Local payment lifecycle record for a Vriendinneklub join order.
owns:
  - payment lifecycle state
  - amount_minor
  - currency
  - payment reference
  - source order relationship
does_not_own:
  - raw provider webhook receipt
  - membership activation state
  - entitlement grants
  - refund state
state:
  - pending
  - succeeded
  - failed
source_of_truth: postgres
tenant_scope: user_scoped
ash_domain_module: VGApp.Commerce
ash_resource_module: VGApp.Commerce.Payment
relationships:
  - belongs_to order
  - has_many payment_events
identities:
  - unique_payment_reference
high_risk_invariants:
  - payment amount must match order total before success
  - failed payment must not activate membership
  - failed payment must not create entitlement grants
actions_active_v0_2:
  - Commerce.submit_order_for_payment
  - Commerce.mark_payment_succeeded
actions_deferred:
  - Commerce.mark_payment_failed
tests_required:
  - submit_order_creates_pending_payment
  - successful_event_marks_payment_succeeded
  - amount_mismatch_blocks_order_paid
  - failed_payment_does_not_activate_membership
open_decisions: []
```

### Store_Blueprint reference notes

- Store payment lifecycle MAY inform payment state and trusted-provider boundaries.
- VG App v0.2 Payment SHALL stay minimal.
- Refunds, stored payment methods, and full payment-intent provider machinery MUST NOT be inherited in v0.2.

---

## Resource: PaymentEvent

```yaml
resource: PaymentEvent
domain: Commerce
purpose: Idempotent trusted payment event record used to apply payment success or failure exactly once.
owns:
  - idempotency_key
  - provider_event_id when available
  - event_type
  - amount_minor
  - currency
  - received_at
  - processing result classification
does_not_own:
  - membership activation
  - entitlement grant creation
  - return/cancel URL meaning
state:
  - received
  - accepted
  - ignored
source_of_truth: postgres
tenant_scope: user_scoped
ash_domain_module: VGApp.Commerce
ash_resource_module: VGApp.Commerce.PaymentEvent
relationships:
  - belongs_to payment
  - belongs_to order
identities:
  - unique_idempotency_key
high_risk_invariants:
  - PaymentEvent SHALL own idempotency
  - duplicate idempotency key must not create a second event row
  - payment return/cancel shall be read-only
  - payment event code must not create memberships or grants directly
actions_active_v0_2:
  - Commerce.record_payment_event
actions_deferred:
  - Commerce.process_provider_webhook_event
tests_required:
  - records_payment_event_once
  - duplicate_payment_event_does_not_create_second_row
  - duplicate_payment_event_is_ignored
  - payment_event_does_not_activate_membership
  - payment_return_cancel_is_read_only
  - payment_code_does_not_create_entitlement_grants
open_decisions: []
```

### Store_Blueprint reference notes

- Store provider event / webhook receipt patterns MAY inform idempotency.
- PaymentEvent SHALL own idempotency in VG App v0.2.
- Return/cancel handlers MUST remain read-only.
- PaymentEvent MUST NOT create memberships or grants directly.
