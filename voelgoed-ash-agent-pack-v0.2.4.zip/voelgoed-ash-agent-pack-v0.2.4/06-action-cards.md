# 06. Action Cards

## Action Card Standard
Each v0.2 action card MUST include this structure.

```yaml-example
action: Domain.action_name
resource: ResourceName
actor: actor_name
trigger: []
preconditions: []
state_changes: []
side_effects: []
transaction_boundary: string
idempotency: string
authorization: string
audit_requirement: string
forbidden_behaviours: []
tests_required: []
open_decisions: []
```

## v0.2 action boundary
Only the actions in this file are available to v0.2 slice packs.

A coding agent MUST NOT invent actions outside this file.

No Store_Blueprint module SHALL be copied from an action card until the module has a focused `KEEP / RENAME / REWRITE / REJECT` extraction decision.


## Cross-resource mutation metadata

Every action card SHALL declare `primary_resource` and `mutates_resources`.

Any action that mutates more than one resource MUST list every mutated resource under `mutates_resources`.

Read-only actions SHALL declare `mutates_resources: []` and `read_only: true`.


---

## Action: Accounts.register_user

```yaml
action: Accounts.register_user
resource: User
actor: public_visitor
trigger:
- registration_form_submitted
preconditions:
- email_is_present
- email_is_unique
state_changes:
- User: null -> active
side_effects:
- enqueue_welcome_email_after_commit_optional
transaction_boundary: creates User in one database transaction
idempotency: duplicate email must return deterministic rejection, not create second
  user
authorization: public visitor allowed
audit_requirement: v0.2 audit evidence SHALL be satisfied by persisted timestamps,
  state fields, source references, and tests. AuditEvent SHALL remain deferred.
forbidden_behaviours:
- creating_membership_implicitly
- creating_order_implicitly
- sending_email_inside_transaction
tests_required:
- registers_user_with_unique_email
- rejects_duplicate_email
- does_not_create_membership
open_decisions: []
primary_resource: User
mutates_resources:
- User
```

### Store_Blueprint alignment

- Store Accounts MAY inform account/auth patterns.
- Store admin/support role assumptions MUST NOT be copied without actor-matrix approval.

---

## Action: Memberships.create_membership_plan

```yaml
action: Memberships.create_membership_plan
resource: MembershipPlan
actor: staff_admin
trigger:
- staff_admin_defines_plan
preconditions:
- actor_is_staff_admin
- plan_code_is_unique
state_changes:
- MembershipPlan: null -> draft
side_effects: []
transaction_boundary: single database transaction
idempotency: duplicate plan_code must be rejected deterministically
authorization: staff_admin only
audit_requirement: v0.2 audit evidence SHALL be satisfied by persisted timestamps,
  state fields, source references, and tests. AuditEvent SHALL remain deferred.
forbidden_behaviours:
- creating_offer_implicitly
- creating_price_implicitly
tests_required:
- staff_admin_can_create_plan
- duplicate_plan_code_rejected
open_decisions: []
primary_resource: MembershipPlan
mutates_resources:
- MembershipPlan
```

---

## Action: Memberships.create_benefit_rule

```yaml
action: Memberships.create_benefit_rule
resource: BenefitRule
actor: staff_admin
trigger:
- staff_admin_defines_benefit_rule
preconditions:
- membership_plan_exists
- benefit_type_is_allowed_v0_2
- rule_code_unique_per_plan
state_changes:
- BenefitRule: null -> draft
side_effects: []
transaction_boundary: single database transaction
idempotency: duplicate rule_code per plan must be rejected deterministically
authorization: staff_admin only
audit_requirement: v0.2 audit evidence SHALL be satisfied by persisted timestamps,
  state fields, source references, and tests. AuditEvent SHALL remain deferred.
forbidden_behaviours:
- creating_user_grants_directly
- using_generic_entitlement_resource
tests_required:
- creates_draft_benefit_rule
- rejects_out_of_scope_benefit_type
- reject_duplicate_rule_code_per_plan
open_decisions: []
primary_resource: BenefitRule
mutates_resources:
- BenefitRule
```

### Store_Blueprint alignment

- BenefitRule SHALL be rewritten for VG App.
- BenefitRule MUST NOT be inferred from Store subscriptions.

---

## Action: Memberships.activate_benefit_rule

```yaml
action: Memberships.activate_benefit_rule
resource: BenefitRule
actor: staff_admin
trigger:
- staff_admin_activates_rule
preconditions:
- membership_plan_exists
- benefit_rule_is_draft
state_changes:
- BenefitRule: draft -> active
side_effects: []
transaction_boundary: single database transaction
idempotency: repeating activation on active rule returns deterministic no-op or rejection
authorization: staff_admin only
audit_requirement: v0.2 audit evidence SHALL be satisfied by persisted timestamps,
  state fields, source references, and tests. AuditEvent SHALL remain deferred.
forbidden_behaviours:
- creating_entitlement_grants_during_rule_activation
tests_required:
- active_benefit_rule_requires_active_plan
open_decisions: []
primary_resource: BenefitRule
mutates_resources:
- BenefitRule
```

---

## Action: Memberships.activate_membership_plan

```yaml
action: Memberships.activate_membership_plan
resource: MembershipPlan
actor: staff_admin
trigger:
- staff_admin_activates_plan
preconditions:
- plan_is_draft
- at_least_one_active_benefit_rule_exists
state_changes:
- MembershipPlan: draft -> active
side_effects: []
transaction_boundary: single database transaction
idempotency: repeating activation on active plan returns deterministic no-op or rejection
authorization: staff_admin only
audit_requirement: v0.2 audit evidence SHALL be satisfied by persisted timestamps,
  state fields, source references, and tests. AuditEvent SHALL remain deferred.
forbidden_behaviours:
- creating_offer_implicitly
tests_required:
- active_plan_requires_benefit_rule
open_decisions: []
primary_resource: MembershipPlan
mutates_resources:
- MembershipPlan
```

---

## Action: Catalog.create_vriendinneklub_offer

```yaml
action: Catalog.create_vriendinneklub_offer
resource: Offer
actor: staff_admin
trigger:
- staff_admin_creates_offer
preconditions:
- membership_plan_exists
- offer_code_unique
- offer_type_is_vriendinneklub_membership
state_changes:
- Offer: null -> draft
side_effects: []
transaction_boundary: single database transaction
idempotency: duplicate offer_code must be rejected deterministically
authorization: staff_admin only
audit_requirement: v0.2 audit evidence SHALL be satisfied by persisted timestamps,
  state fields, source references, and tests. AuditEvent SHALL remain deferred.
forbidden_behaviours:
- creating_product_variant
- creating_inventory_item
tests_required:
- creates_vriendinneklub_offer_for_membership_plan
- rejects_non_membership_offer_type_in_v0_2
- rejects_duplicate_offer_code
open_decisions: []
primary_resource: Offer
mutates_resources:
- Offer
```

### Store_Blueprint alignment

- Store Catalog MUST NOT be inherited blindly.
- Product, Variant, InventoryItem, ProductOption, and ProductImage MUST NOT be required.

---

## Action: Catalog.create_vriendinneklub_price

```yaml
action: Catalog.create_vriendinneklub_price
resource: Price
actor: staff_admin
trigger:
- staff_admin_creates_price
preconditions:
- offer_exists
- amount_minor_positive
- currency_present
state_changes:
- Price: null -> draft
side_effects: []
transaction_boundary: single database transaction
idempotency: duplicate active price is impossible because create starts draft
authorization: staff_admin only
audit_requirement: v0.2 audit evidence SHALL be satisfied by persisted timestamps,
  state fields, source references, and tests. AuditEvent SHALL remain deferred.
forbidden_behaviours:
- creating_coupon
- creating_promotion
- creating_tax_rule
tests_required:
- creates_draft_price_for_vriendinneklub_offer
- active_price_requires_positive_amount
open_decisions: []
primary_resource: Price
mutates_resources:
- Price
```

---

## Action: Catalog.activate_vriendinneklub_price

```yaml
action: Catalog.activate_vriendinneklub_price
resource: Price
actor: staff_admin
trigger:
- staff_admin_activates_price
preconditions:
- price_is_draft
- no_other_active_price_for_offer
state_changes:
- Price: draft -> active
side_effects: []
transaction_boundary: single database transaction
idempotency: second active price per offer must be rejected
authorization: staff_admin only
audit_requirement: v0.2 audit evidence SHALL be satisfied by persisted timestamps,
  state fields, source references, and tests. AuditEvent SHALL remain deferred.
forbidden_behaviours:
- activating_multiple_prices_for_same_offer
tests_required:
- activates_single_price_per_offer
- rejects_second_active_price
open_decisions: []
primary_resource: Price
mutates_resources:
- Price
```

---

## Action: Catalog.activate_vriendinneklub_offer

```yaml
action: Catalog.activate_vriendinneklub_offer
resource: Offer
actor: staff_admin
trigger:
- staff_admin_activates_offer
preconditions:
- offer_is_draft
- one_active_price_exists
state_changes:
- Offer: draft -> active
side_effects: []
transaction_boundary: single database transaction
idempotency: repeating activation on active offer returns deterministic no-op or rejection
authorization: staff_admin only
audit_requirement: v0.2 audit evidence SHALL be satisfied by persisted timestamps,
  state fields, source references, and tests. AuditEvent SHALL remain deferred.
forbidden_behaviours:
- activating_offer_without_active_price
tests_required:
- active_offer_requires_one_active_price
open_decisions: []
primary_resource: Offer
mutates_resources:
- Offer
```

---

## Action: Catalog.snapshot_price_for_order_item

```yaml
action: Catalog.snapshot_price_for_order_item
resource: Price
actor: system
trigger:
- Commerce.add_vriendinneklub_order_item_needs_snapshot
preconditions:
- offer_is_active
- price_is_active
- membership_plan_is_active
state_changes:
- read_only_snapshot_generated
side_effects: []
transaction_boundary: read-only inside Commerce action transaction
idempotency: snapshot must be deterministic for the given offer/price at creation
  time
authorization: system through Commerce action only
audit_requirement: v0.2 audit evidence SHALL be satisfied by persisted timestamps,
  state fields, source references, and tests. AuditEvent SHALL remain deferred.
forbidden_behaviours:
- mutating_live_price
- using_product_variant
- using_tax_shipping_coupon_engine
tests_required:
- snapshot_contains_amount_currency_and_price_source
- snapshot_does_not_mutate_price
open_decisions: []
primary_resource: Price
mutates_resources: []
read_only: true
```

### Store_Blueprint alignment

- Store Pricing MAY inform deterministic evaluation and snapshot discipline.
- Coupons, promotions, shipping, tax, and eligibility engines MUST NOT be inherited in v0.2.

---

## Action: Commerce.create_pending_order

```yaml
action: Commerce.create_pending_order
resource: Order
actor: registered_user
trigger:
- registered_user_starts_join_order
preconditions:
- actor_is_active_registered_user
- no_active_membership_exists_or_policy_allows_pending_reuse
state_changes:
- Order: null -> pending_payment
side_effects: []
transaction_boundary: single database transaction
idempotency: one active pending Vriendinneklub order per user/plan; reuse per D-014
authorization: registered_user own order only
audit_requirement: v0.2 audit evidence SHALL be satisfied by persisted timestamps,
  state fields, source references, and tests. AuditEvent SHALL remain deferred.
forbidden_behaviours:
- cart_first_checkout
- creating_payment_success
- activating_membership
tests_required:
- active_user_can_create_pending_join_order
- suspended_user_cannot_create_pending_join_order
open_decisions: []
primary_resource: Order
mutates_resources:
- Order
```

### Store_Blueprint alignment

- Store order creation/idempotency MAY inform implementation.
- Cart-first checkout MUST NOT be inherited.
- Order creation SHALL require a registered user actor in v0.2.

---

## Action: Commerce.add_vriendinneklub_order_item

```yaml
action: Commerce.add_vriendinneklub_order_item
resource: OrderItem
actor: registered_user
trigger:
- pending_order_created
preconditions:
- order_is_pending_payment
- offer_is_active
- quantity_is_one
state_changes:
- OrderItem: null -> active
side_effects: []
transaction_boundary: same transaction as pending order creation where possible
idempotency: one Vriendinneklub item per order
authorization: registered_user own order only
audit_requirement: v0.2 audit evidence SHALL be satisfied by persisted timestamps,
  state fields, source references, and tests. AuditEvent SHALL remain deferred.
forbidden_behaviours:
- using_product_variant
- using_inventory
- using_coupon_or_bundle
tests_required:
- adds_vriendinneklub_item_with_price_snapshot
- order_item_snapshots_price_at_creation
- rejects_quantity_above_one_in_v0_2
- rejects_duplicate_vriendinneklub_item_for_order
open_decisions: []
primary_resource: OrderItem
mutates_resources:
- OrderItem
```

### Store_Blueprint alignment

- Store OrderLineItem snapshot patterns MAY inform this action.
- Product/variant/inventory fields MUST NOT be required.

---

## Action: Commerce.submit_order_for_payment

```yaml
action: Commerce.submit_order_for_payment
resource: Payment
actor: registered_user
trigger:
- registered_user_submits_pending_order
preconditions:
- order_is_pending_payment
- order_has_one_vriendinneklub_order_item
- order_total_matches_snapshot
state_changes:
- Payment: null -> pending
side_effects: []
transaction_boundary: single database transaction
idempotency: repeated submit reuses existing pending payment where safe
authorization: registered_user own order only
audit_requirement: v0.2 audit evidence SHALL be satisfied by persisted timestamps,
  state fields, source references, and tests. AuditEvent SHALL remain deferred.
forbidden_behaviours:
- marking_payment_succeeded
- activating_membership
- creating_grants
tests_required:
- submit_order_creates_pending_payment
- submit_order_moves_order_to_pending_payment
- submit_order_does_not_activate_membership
open_decisions: []
primary_resource: Payment
mutates_resources:
- Payment
```

---

## Action: Memberships.create_pending_membership

```yaml
action: Memberships.create_pending_membership
resource: Membership
actor: registered_user
trigger:
- pending_join_order_created
preconditions:
- registered_user_actor
- pending_order_exists
- membership_plan_exists
state_changes:
- Membership: null -> pending_payment
side_effects: []
transaction_boundary: same transaction as pending join order creation where possible
idempotency: one active or pending membership per user/plan
authorization: registered_user own membership only
audit_requirement: v0.2 audit evidence SHALL be satisfied by persisted timestamps,
  state fields, source references, and tests. AuditEvent SHALL remain deferred.
forbidden_behaviours:
- granting_access
- activating_membership_without_payment
tests_required:
- creates_pending_membership_for_join_order
- pending_membership_does_not_grant_access
open_decisions: []
primary_resource: Membership
mutates_resources:
- Membership
```

---

## Action: Commerce.record_payment_event

```yaml
action: Commerce.record_payment_event
resource: PaymentEvent
actor: system
trigger:
- trusted_manual_payment_confirmation
preconditions:
- payment_exists
- order_exists
- idempotency_key_present
- amount_and_currency_present
state_changes:
- PaymentEvent: null -> received
side_effects: []
transaction_boundary: single database transaction before payment success transition
idempotency: PaymentEvent.idempotency_key is unique; duplicate returns existing event
  or deterministic ignored result
authorization: system only
audit_requirement: v0.2 audit evidence SHALL be satisfied by persisted timestamps,
  state fields, source references, and tests. AuditEvent SHALL remain deferred.
forbidden_behaviours:
- activating_membership_directly
- creating_entitlement_grants
- trusting_return_url
tests_required:
- records_payment_event_once
- duplicate_payment_event_does_not_create_second_row
- duplicate_payment_event_is_ignored
- payment_event_does_not_activate_membership
- payment_return_cancel_is_read_only
open_decisions: []
primary_resource: PaymentEvent
mutates_resources:
- PaymentEvent
```

### Store_Blueprint alignment

- Store ProviderEvent/WebhookReceipt MAY inform trusted event ingestion.
- This action SHALL be idempotent.
- This action MUST NOT activate membership directly.

---

## Action: Commerce.mark_payment_succeeded

```yaml
action: Commerce.mark_payment_succeeded
resource: Payment
actor: system
trigger:
- accepted_payment_event_recorded
preconditions:
- trusted_payment_event_exists
- amount_matches_order_total
- currency_matches_order_currency
state_changes:
- Payment: pending -> succeeded
- PaymentEvent: received -> accepted
side_effects: []
transaction_boundary: single database transaction
idempotency: duplicate success event does not duplicate success effects
authorization: system only
audit_requirement: v0.2 audit evidence SHALL be satisfied by persisted timestamps,
  state fields, source references, and tests. AuditEvent SHALL remain deferred.
forbidden_behaviours:
- creating_entitlement_grants
- activating_membership
- recalculating_order_total
tests_required:
- successful_event_marks_payment_succeeded
- amount_mismatch_blocks_order_paid
- duplicate_success_event_does_not_duplicate_success_effects
open_decisions: []
primary_resource: Payment
mutates_resources:
- Payment
- PaymentEvent
```

### Store_Blueprint alignment

- Store payment-success-once pattern MAY inform this action.
- Payment success MUST be applied once.
- Payment return/cancel MUST NOT call this action.

---

## Action: Commerce.mark_order_paid

```yaml
action: Commerce.mark_order_paid
resource: Order
actor: system
trigger:
- payment_succeeded
preconditions:
- payment_is_succeeded
- order_is_pending_payment
- order_total_matches_payment
state_changes:
- Order: pending_payment -> paid
side_effects:
- VS-002C SHALL end with Order.state == paid.
- Commerce.mark_order_paid SHALL NOT create Membership records.
- Commerce.mark_order_paid SHALL NOT create EntitlementGrant records.
- VS-002D SHALL explicitly call Memberships.activate_membership from the paid-order
  state.
- VS-002D SHALL explicitly call Memberships.create_entitlement_grants after membership
  activation.
transaction_boundary: single database transaction; VS-002C ends at paid order; VS-002D
  owns membership activation and grant creation
idempotency: repeated mark paid must be safe and not duplicate downstream activation
authorization: system only
audit_requirement: v0.2 audit evidence SHALL be satisfied by persisted timestamps,
  state fields, source references, and tests. AuditEvent SHALL remain deferred.
forbidden_behaviours:
- recalculating_prices
- creating_grants_directly
- creating_membership_records
- creating_entitlement_grants
tests_required:
- succeeded_payment_marks_order_paid
- duplicate_mark_order_paid_does_not_duplicate_activation
- mark_order_paid_does_not_activate_membership
- mark_order_paid_does_not_create_grants
open_decisions: []
primary_resource: Order
mutates_resources:
- Order
```

### Store_Blueprint alignment

- Store paid-order lifecycle MAY inform this action.
- This action SHALL run only after trusted PaymentEvent success.

---

## Action: Memberships.activate_membership

```yaml
action: Memberships.activate_membership
resource: Membership
actor: system
trigger:
- order_marked_paid
preconditions:
- order_is_paid
- membership_is_pending_payment
- manual_admin_activation_excluded
state_changes:
- Membership: pending_payment -> active
side_effects: []
transaction_boundary: after order-paid success boundary per D-015
idempotency: duplicate activation returns existing active membership and must not
  duplicate grants
authorization: system only
audit_requirement: v0.2 audit evidence SHALL be satisfied by persisted timestamps,
  state fields, source references, and tests. AuditEvent SHALL remain deferred.
forbidden_behaviours:
- activating_without_paid_order
- staff_admin_manual_activation_in_v0_2
tests_required:
- paid_order_activates_membership
- unpaid_order_cannot_activate_membership
- duplicate_activation_is_safe
- paid_order_activates_membership_once
open_decisions: []
primary_resource: Membership
mutates_resources:
- Membership
```

### Store_Blueprint alignment

- Store subscription activation MAY inform future recurring design only.
- v0.2 membership activation SHALL depend on paid order/payment success.

---

## Action: Memberships.create_entitlement_grants

```yaml
action: Memberships.create_entitlement_grants
resource: EntitlementGrant
actor: system
trigger:
- membership_activated
preconditions:
- membership_is_active
- benefit_rules_are_active
- source_order_id_present
- source_membership_id_present
state_changes:
- EntitlementGrant: null -> active
side_effects: []
transaction_boundary: single database transaction after membership activation
idempotency: grant uniqueness prevents duplicate grants for same user/rule/membership/source
authorization: system only
audit_requirement: v0.2 audit evidence SHALL be satisfied by persisted timestamps,
  state fields, source references, and tests. AuditEvent SHALL remain deferred.
forbidden_behaviours:
- payment_code_creating_grants
- using_generic_entitlement_resource
tests_required:
- active_membership_creates_expected_grants_once
- duplicate_grant_creation_is_idempotent
- archived_benefit_rule_does_not_create_grants
- benefit_rule_creates_expected_grants
open_decisions: []
primary_resource: EntitlementGrant
mutates_resources:
- EntitlementGrant
```

### Store_Blueprint alignment

- Store EntitlementGrant MAY inform persisted grant shape.
- Grants SHALL be created from BenefitRule.
- Payment code MUST NOT create grants directly.

---

## Action: Memberships.evaluate_entitlement_access

```yaml
action: Memberships.evaluate_entitlement_access
resource: EntitlementGrant
actor: registered_user_or_system
trigger:
- protected_access_check_requested
preconditions:
- user_exists
- benefit_scope_requested
state_changes:
- read_only_no_state_change
side_effects: []
transaction_boundary: read-only query/action
idempotency: same inputs produce same access decision unless grant state changes
authorization: registered_user own grants or system
audit_requirement: v0.2 audit evidence SHALL be satisfied by persisted timestamps,
  state fields, source references, and tests. AuditEvent SHALL remain deferred.
forbidden_behaviours:
- mutating_state
- creating_grants
- loading_content_learning_event_models
tests_required:
- active_grant_allows_access
- revoked_grant_denies_access
- expired_grant_denies_access
- wrong_user_grant_denied
- access_evaluation_does_not_mutate_state
- pending_membership_fails_access_evaluation
open_decisions: []
primary_resource: EntitlementGrant
mutates_resources: []
read_only: true
```

### Store_Blueprint alignment

- Store entitlement-aware access patterns MAY inform read-side checks.
- This action MUST NOT mutate state.
