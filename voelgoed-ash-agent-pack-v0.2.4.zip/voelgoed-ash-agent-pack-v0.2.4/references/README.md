# References

This folder contains planning reference material only.

## Store_Blueprint

`STORE_BLUEPRINT_EXTRACTION_DECISION_V1.md` is included as a planning decision reference.

Store_Blueprint SHALL be used only as:

- reference implementation
- selective extraction source
- governance source
- payment/idempotency pattern source
- Ash boundary pattern source

Store_Blueprint MUST NOT be used as the VG App implementation baseline.

No Store_Blueprint module SHALL be copied until it has a focused `KEEP / RENAME / REWRITE / REJECT` extraction decision.
