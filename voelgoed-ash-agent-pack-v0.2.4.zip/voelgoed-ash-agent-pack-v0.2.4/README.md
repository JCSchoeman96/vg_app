# VG App Ash Agent Planning Pack v0.2.4

## Status
This pack is a v0.2.4 mechanical-enforcement planning baseline for **VG App**.

Planning status: `READY_FOR_REVIEW_CLEAN`.

Coding status: `NOT_READY`.

No coding agent SHALL implement from this pack until the executable planning validator passes and a vertical-slice execution grill marks that specific slice READY_FOR_CODING.

## Project identity

```yaml
product_human_name: VG App
display_name: VG App
github_repo: vg_app
app_folder: vg_app
elixir_root_module: VGApp
phoenix_web_module: VGAppWeb
otp_app_atom: :vg_app
main_lib_path: lib/vg_app
web_lib_path: lib/vg_app_web
repo_module: VGApp.Repo
endpoint_module: VGAppWeb.Endpoint
```

## v0.2 authority

v0.2 is limited to the **Join Vriendinneklub** path.

A coding agent MUST NOT implement from general project context, domain descriptions, or broad business prose.

A coding agent SHALL implement only from an approved slice pack marked `READY_FOR_CODING`, and only after all referenced resource cards, action cards, state transitions, tests, and decisions are complete and validator-passing.

## Store_Blueprint reference authority

Store_Blueprint SHALL be treated as a reference/extraction source only.

Store_Blueprint MUST NOT be used as the implementation baseline.

Store_Blueprint MUST NOT be forked blindly.

No Store_Blueprint module SHALL be copied until it has a focused `KEEP / RENAME / REWRITE / REJECT` extraction decision.

The binding Store_Blueprint planning reference is:

- `references/STORE_BLUEPRINT_EXTRACTION_DECISION_V1.md`

This reference SHALL NOT expand v0.2 beyond the Join Vriendinneklub path.

## v0.2 allowed scope

The v0.2 scope SHALL include only:

- account registration
- Vriendinneklub membership plan definition
- Vriendinneklub benefit rules
- Vriendinneklub offer and price
- pending join order creation
- order item price snapshot
- simulated/manual trusted payment event recording
- payment success transition
- membership activation
- entitlement grant creation from benefit rules
- read-only entitlement access evaluation

## v0.2 forbidden scope

v0.2 MUST NOT include:

- Events
- Learning
- Competitions
- Media
- Community
- bundles
- coupon stacking
- full refunds
- event tickets
- organiser portal
- full catalog abstraction
- generic entitlement engine
- Shipping
- Tax
- FulfilmentDispatch
- AuditEvent
- product variants
- inventory
- cart-first checkout
- digital downloads
- subscriptions implementation

## Read order

1. `planning-pack.yml`
2. `README.md`
3. `00-project-seed-brief.md`
4. `01-assumption-register.md`
5. `02-risk-surface-map.md`
6. `03-workflow-inventory.md`
7. `04-domain-map.md`
8. `05-resource-cards.md`
9. `06-action-cards.md`
10. `07-tenancy-ownership-map.md`
11. `08-slice-matrix.md`
12. `11-open-decisions.md`
13. `12-actor-permission-matrix.md`
14. `13-state-transition-map.yml`
15. `14-test-matrix.yml`
16. `15-planning-validator-rules.md`
17. `references/STORE_BLUEPRINT_EXTRACTION_DECISION_V1.md`
18. one file under `slice-packs/`

## Implementation gate

Executable validator command:

```bash
python tools/validate_planning_pack.py .
```


Slices MAY be `READY_FOR_REVIEW_CLEAN` after v0.2.4 cleanup.

No slice SHALL be marked `READY_FOR_CODING` until:

- all machine-readable YAML blocks parse;
- the planning validator exists;
- the planning validator passes;
- all referenced files/resources/actions/tests exist;
- no forbidden scope item is introduced;
- no Store_Blueprint module copy is authorized without `KEEP / RENAME / REWRITE / REJECT`.

## Pre-coding verification checklist

### Already satisfied by v0.2.4

- [x] planning-pack.yml exists.
- [x] VGApp namespace is locked.
- [x] No MyApp placeholders remain.
- [x] Store_Blueprint reference-only rule is included.
- [x] No blind Store module copying is allowed.
- [x] VS-002E exists.
- [x] BenefitRule + EntitlementGrant shape is locked.
- [x] PaymentEvent idempotency is locked.
- [x] Manual admin activation is excluded from v0.2.
- [x] Full refunds are deferred.
- [x] AuditEvent is deferred.
- [x] v0.2 scope is limited to Join Vriendinneklub.
- [x] Resource/action/test parity is checked.
- [x] Executable planning validator exists.
- [x] Executable planning validator passes for this pack.

### Still required before READY_FOR_CODING

- [ ] At least one vertical slice MUST pass a READY_FOR_CODING grill.
- [ ] No Store_Blueprint module may be copied without KEEP / RENAME / REWRITE / REJECT.
- [ ] No implementation may begin from READY_FOR_REVIEW_CLEAN status alone.
- [ ] The executable validator MUST be rerun after any planning-pack change.
