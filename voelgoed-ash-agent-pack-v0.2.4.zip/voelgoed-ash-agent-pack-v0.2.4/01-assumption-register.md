# 01. Assumption Register

## v0.2 assumption policy
Only assumptions required for the Join Vriendinneklub path are active in v0.2.

Future-domain assumptions MUST remain deferred and MUST NOT drive resource/action creation.

| ID | Assumption | Risk if wrong | Validation required | Status |
|---|---|---|---|---|
| A-001 | Vriendinneklub is the correct first commercial path | v0.2 optimises the wrong revenue path | Leadership confirms membership purchase is priority | Open |
| A-002 | Registration can exist before the commercial join flow | Checkout may need guest-to-user conversion | Lock D-013 before VS-001A/VS-002B readiness | Open |
| A-003 | Vriendinneklub can be sold through a minimal `Offer` + `Price` model | Catalog may be over- or under-modelled | Prove with VS-002A only | Open |
| A-004 | `OrderItem` price snapshot is required at order creation | Historical orders become mutable if live price is reused | Lock D-010 | Open |
| A-005 | Payment confirmation is represented by `PaymentEvent` | Duplicate gateway events may activate membership twice | Lock D-011 | Open |
| A-006 | `BenefitRule` can define v0.2 access benefits | Access rules may become duplicated | Lock D-002 | Open |
| A-007 | `EntitlementGrant` is a persisted grant derived from active membership + benefit rule | Access may be granted without a traceable source | Lock D-002 | Open |
| A-008 | Full refund implementation can be deferred | Future reversal logic may be boxed in by v0.2 design | Lock D-005 as a future constraint | Open |
| A-009 | AuditEvent is not required as a resource in v0.2 | Later compliance may require stronger audit trails | Capture audit requirements inside action cards | Open |
| A-010 | FulfilmentDispatch is not required as a resource in v0.2 | Later commerce flows may need a durable dispatch model | Keep membership activation explicit in action cards | Open |

## Deferred assumptions
The following assumptions are out of scope for v0.2 and MUST NOT create resource/action cards yet:

- shared taxonomy across business areas
- event organiser tenancy
- course/webinar enrolments
- competitions and voting
- media scheduling
- community features
- coupon stacking
- bundles
- full refunds


---

## Store_Blueprint extraction authority

Assumption: Store_Blueprint is a reference/extraction source only.

Binding rule: This assumption is locked by D-017 and `references/STORE_BLUEPRINT_EXTRACTION_DECISION_V1.md`.

A coding agent MUST NOT copy Store_Blueprint modules without a focused `KEEP / RENAME / REWRITE / REJECT` extraction decision.
