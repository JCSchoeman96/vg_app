#!/usr/bin/env python3
"""Executable validator for the VG App v0.2.4 planning pack.

This validator is intentionally conservative. It checks planning-pack consistency only.
It does not authorize coding and does not inspect implementation code.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path
from typing import Any

try:
    import yaml
except Exception as exc:  # pragma: no cover
    print(f"FAIL: PV-000 PyYAML is required: {exc}")
    sys.exit(1)

CHECKS: list[tuple[str, str, bool]] = []

FORBIDDEN_SCOPE_TERMS = [
    "Events", "Learning", "Competitions", "Media", "Community", "Shipping", "Tax",
    "FulfilmentDispatch", "AuditEvent", "GenericCatalog", "ProductVariants", "Inventory",
    "CartFirstCheckout", "FullRefunds", "Bundles", "CouponStacking", "OrganiserPortal",
    "DigitalDownloads", "SubscriptionsImplementation",
]

STORE_MODULE_PATTERN = re.compile(r"\bStore\.(?:Catalog|Carts|Checkout|Shipping|Payments|Orders|Subscriptions|Digital|Fulfillment|Entitlements|Admin|Accounts)\.[A-Za-z0-9_.]+")
YAML_FENCE_RE = re.compile(r"```(yaml|yml|yaml-example)\n(.*?)\n```", re.S)


def record(check_id: str, description: str, ok: bool) -> None:
    CHECKS.append((check_id, description, ok))
    print(("PASS" if ok else "FAIL") + f": {check_id} {description}")


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def load_yaml_file(path: Path) -> Any:
    return yaml.safe_load(read(path))


def yaml_blocks(root: Path):
    for path in sorted(root.rglob("*")):
        if path.is_file() and path.suffix in {".md", ".yml", ".yaml"}:
            text = read(path)
            for match in YAML_FENCE_RE.finditer(text):
                yield path, match.group(1), match.group(2)


def yaml_cards_from_markdown(path: Path, key: str) -> list[dict[str, Any]]:
    cards: list[dict[str, Any]] = []
    for match in YAML_FENCE_RE.finditer(read(path)):
        lang, body = match.group(1), match.group(2)
        if lang not in {"yaml", "yml"}:
            continue
        data = yaml.safe_load(body)
        if isinstance(data, dict) and key in data:
            cards.append(data)
    return cards


def slice_refs(path: Path) -> tuple[list[str], list[str], list[str], str]:
    text = read(path)
    resources = extract_bullets_after(text, "## Resources involved")
    actions = extract_bullets_after(text, "## Actions involved")
    blockers = extract_bullets_after(text, "## Blocking decisions")
    status = "READY_FOR_CODING" if "READY_FOR_CODING" in text and "does not mean" not in text else ""
    if "## Status" in text:
        m = re.search(r"## Status\s*\n([^\n]+)", text)
        if m:
            status = m.group(1).strip()
    return resources, actions, blockers, status


def extract_bullets_after(text: str, heading: str) -> list[str]:
    idx = text.find(heading)
    if idx == -1:
        return []
    rest = text[idx + len(heading):]
    next_heading = re.search(r"\n## ", rest)
    if next_heading:
        rest = rest[: next_heading.start()]
    items: list[str] = []
    for line in rest.splitlines():
        line = line.strip()
        if line.startswith("- "):
            value = line[2:].strip().strip("`")
            if value and value.lower() != "none":
                items.append(value)
    return items


def collect_tests_from_cards(cards: list[dict[str, Any]]) -> set[str]:
    tests: set[str] = set()
    for card in cards:
        for t in card.get("tests_required") or []:
            tests.add(str(t))
    return tests


def collect_tests_from_any(obj: Any) -> set[str]:
    tests: set[str] = set()
    if isinstance(obj, dict):
        for k, v in obj.items():
            if k in {"tests", "tests_required", "required_tests", "global_required_tests"} and isinstance(v, list):
                tests.update(str(x) for x in v)
            else:
                tests.update(collect_tests_from_any(v))
    elif isinstance(obj, list):
        for v in obj:
            tests.update(collect_tests_from_any(v))
    return tests


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    root = root.resolve()

    pack_path = root / "planning-pack.yml"
    record("PV-001", "planning-pack.yml exists", pack_path.exists())
    try:
        pack = load_yaml_file(pack_path)
        record("PV-001B", "planning-pack.yml parses", isinstance(pack, dict))
    except Exception as exc:
        record("PV-001B", f"planning-pack.yml parses ({exc})", False)
        pack = {}

    # PV-002 all YAML fences parse
    yaml_ok = True
    for path, lang, body in yaml_blocks(root):
        try:
            yaml.safe_load(body)
        except Exception as exc:
            yaml_ok = False
            print(f"FAIL: PV-002 {path.relative_to(root)} {lang} YAML fence failed: {exc}")
    record("PV-002", "all YAML fences parse", yaml_ok)

    resource_cards = yaml_cards_from_markdown(root / "05-resource-cards.md", "resource")
    action_cards = yaml_cards_from_markdown(root / "06-action-cards.md", "action")
    resources = {c["resource"]: c for c in resource_cards}
    actions = {c["action"]: c for c in action_cards}

    pack_resources = set(pack.get("resources") or [])
    record("PV-003", "all planning-pack resources have resource cards", pack_resources <= set(resources))

    slice_dir = root / "slice-packs"
    slice_files = sorted(slice_dir.glob("VS-*.md"))
    pack_slices = set(pack.get("slices") or [])
    existing_slice_ids = {p.name.split("-")[0] + "-" + p.name.split("-")[1].split(".")[0] if p.name.startswith("VS-") else p.stem for p in slice_files}
    # Less clever: parse first two filename parts e.g. VS-002A
    existing_slice_ids = {p.name.split("-")[0] + "-" + p.name.split("-")[1] for p in slice_files}
    record("PV-004", "all planning-pack slices exist under slice-packs", pack_slices <= existing_slice_ids)

    slice_resource_ok = True
    slice_action_ok = True
    deferred_used_ok = True
    ready_for_coding_ok = True
    locked_blocker_ok = True
    locked_decisions = locked_decision_ids(root / "11-open-decisions.md")
    deferred_actions = set()
    for c in resource_cards:
        deferred_actions.update(str(a) for a in (c.get("actions_deferred") or []))

    for sf in slice_files:
        sresources, sactions, blockers, status = slice_refs(sf)
        missing_r = [r for r in sresources if r not in resources]
        missing_a = [a for a in sactions if a not in actions]
        if missing_r:
            slice_resource_ok = False
            print(f"FAIL: PV-005 {sf.name} missing resource cards: {missing_r}")
        if missing_a:
            slice_action_ok = False
            print(f"FAIL: PV-006 {sf.name} missing action cards: {missing_a}")
        used_deferred = [a for a in sactions if a in deferred_actions]
        if used_deferred:
            deferred_used_ok = False
            print(f"FAIL: PV-007 {sf.name} uses deferred actions: {used_deferred}")
        if status == "READY_FOR_CODING" and blockers:
            ready_for_coding_ok = False
            print(f"FAIL: PV-010 {sf.name} READY_FOR_CODING with blockers: {blockers}")
        locked_as_blockers = [b for b in blockers if b in locked_decisions]
        if locked_as_blockers:
            locked_blocker_ok = False
            print(f"FAIL: PV-013 {sf.name} locked decisions listed as blockers: {locked_as_blockers}")

    record("PV-005", "all slice resources have resource cards", slice_resource_ok)
    record("PV-006", "all slice actions have action cards", slice_action_ok)
    record("PV-007", "deferred actions are not used by active slices", deferred_used_ok)

    active_action_refs = set()
    for c in resource_cards:
        active_action_refs.update(str(a) for a in (c.get("actions_active_v0_2") or []))
    record("PV-008", "all active resource actions have action cards", active_action_refs <= set(actions))

    matrix_path = root / "14-test-matrix.yml"
    try:
        matrix_tests = collect_tests_from_any(load_yaml_file(matrix_path))
        card_tests = collect_tests_from_cards(resource_cards) | collect_tests_from_cards(action_cards)
        missing_tests = sorted(card_tests - matrix_tests)
        if missing_tests:
            print(f"FAIL: PV-009 missing tests in matrix: {missing_tests}")
        record("PV-009", "all resource/action tests appear in 14-test-matrix.yml", not missing_tests)
    except Exception as exc:
        record("PV-009", f"test matrix coverage check ({exc})", False)

    all_text = "\n".join(read(p) for p in root.rglob("*") if p.is_file() and p.suffix in {".md", ".yml", ".yaml"})
    record("PV-010", "no legacy MyApp namespace placeholders exist", not re.search(r"\bMyApp\.|:my_app|lib/my_app", all_text))
    record("PV-011", "no READY_FOR_CODING slice with blockers", ready_for_coding_ok)
    record("PV-012", "Store_Blueprint decision file exists", (root / "references/STORE_BLUEPRINT_EXTRACTION_DECISION_V1.md").exists())

    forbidden_ok = True
    forbidden_hits: list[str] = []
    for sf in slice_files:
        sresources, sactions, _blockers, _status = slice_refs(sf)
        active_refs = set(sresources + sactions)
        for term in FORBIDDEN_SCOPE_TERMS:
            if term in active_refs:
                forbidden_ok = False
                forbidden_hits.append(f"{sf.name}:{term}")
    if forbidden_hits:
        print(f"FAIL: PV-012B forbidden active scope hits: {forbidden_hits}")
    record("PV-012B", "no active slice requires forbidden v0.2 scope", forbidden_ok)
    record("PV-013", "locked decisions are not listed as blockers", locked_blocker_ok)

    # VS-002C/D boundaries
    vs002c = read(root / "slice-packs/VS-002C-record-payment-event.md")
    vs002d = read(root / "slice-packs/VS-002D-activate-membership-and-grants.md")
    c_ok = all(phrase in vs002c for phrase in [
        "VS-002C MUST NOT activate membership",
        "VS-002C MUST NOT create entitlement grants",
        "VS-002C MUST stop when `Order.state == paid`",
    ])
    d_ok = all(phrase in vs002d for phrase in [
        "VS-002D SHALL start from an already-paid order",
        "VS-002D SHALL activate membership through `Memberships.activate_membership`",
        "VS-002D SHALL create grants through `Memberships.create_entitlement_grants`",
    ])
    record("PV-014", "VS-002C does not activate membership or create grants", c_ok)
    record("PV-015", "VS-002D owns activation and grant creation", d_ok)

    # Action metadata
    metadata_ok = True
    for action, card in actions.items():
        if "primary_resource" not in card or "mutates_resources" not in card:
            metadata_ok = False
            print(f"FAIL: PV-016 {action} missing primary_resource/mutates_resources")
        if action == "Commerce.mark_order_paid" and any(r in card.get("mutates_resources", []) for r in ["Membership", "EntitlementGrant"]):
            metadata_ok = False
            print("FAIL: PV-016 Commerce.mark_order_paid mutates Membership/EntitlementGrant")
    record("PV-016", "actions declare primary_resource and mutates_resources", metadata_ok)

    failed = [c for c in CHECKS if not c[2]]
    return 1 if failed else 0


def locked_decision_ids(path: Path) -> set[str]:
    text = read(path)
    locked: set[str] = set()
    for m in re.finditer(r"(D-\d{3}).{0,120}?status:\s*LOCKED", text, re.S):
        locked.add(m.group(1))
    # Also catch headings followed by status LOCKED within same section.
    for sec in re.split(r"\n## ", text):
        mid = re.search(r"(D-\d{3})", sec)
        if mid and re.search(r"status:\s*LOCKED|Status:\s*LOCKED", sec):
            locked.add(mid.group(1))
    return locked


if __name__ == "__main__":
    sys.exit(main())
