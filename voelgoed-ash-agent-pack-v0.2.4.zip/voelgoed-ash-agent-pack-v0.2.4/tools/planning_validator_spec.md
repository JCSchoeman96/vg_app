# Planning Validator Spec v0.2.4

This is a validator contract only. It is not implementation code.

## Required checks

- PV-001: `planning-pack.yml` exists.
- PV-002: Every resource listed in `planning-pack.yml` exists in `05-resource-cards.md`.
- PV-003: Every slice listed in `planning-pack.yml` exists under `slice-packs/`.
- PV-004: Every slice resource ref exists as a resource card.
- PV-005: Every slice action ref exists as an action card.
- PV-006: `READY_FOR_CODING` slices MUST have no open blockers.
- PV-007: Locked decisions MUST NOT appear in `blocking_decisions`.
- PV-008: legacy placeholder namespaces MUST NOT exist after D-016.
- PV-009: Store_Blueprint modules MUST NOT appear as implementation dependencies.
- PV-010: Store_Blueprint references MUST point to `references/STORE_BLUEPRINT_EXTRACTION_DECISION_V1.md`.
- PV-011: No v0.2 forbidden scope item may appear as required implementation dependency.
- PV-012: Every action listed under `actions_active_v0_2` MUST have an action card.
- PV-013: `actions_deferred` items MUST NOT be required by v0.2 slices.
- PV-014: Every test listed in resource/action cards MUST appear in `14-test-matrix.yml`.
- PV-015: Empty YAML list fields MUST use `[]` not null.
- PV-016: Example YAML blocks MUST NOT parse as real resource/action cards.
- PV-017: PaymentEvent idempotency rule MUST exist.
- PV-018: Payment return/cancel read-only rule MUST exist.
- PV-019: BenefitRule MUST be source of EntitlementGrant creation.
- PV-020: Order MUST NOT have `failed` or `payment_failed` state in v0.2.
- PV-021: Price MUST use `amount_minor` and `currency`.
- PV-022: AuditEvent MUST remain deferred in v0.2.
- PV-023: VS-002E MUST exist as a separate access-evaluation slice.

- PV-024: All machine-readable YAML blocks MUST parse successfully.
- PV-025: Invalid YAML in resource/action cards SHALL fail validation.
- PV-026: Every `tests_required` item in resource/action cards MUST exist in `14-test-matrix.yml`.
- PV-027: Duplicate semantic test names with different spelling SHALL fail validation.

## Forbidden implementation dependency examples

The validator SHALL fail if any of these are used as required implementation dependencies in active v0.2 slices:

```text
Store.Catalog.Product
Store.Catalog.Variant
Store.Catalog.InventoryItem
Store.Carts.Cart
Store.Checkout.CheckoutDraft
Store.Shipping
Store.Pricing.TaxRate
Store.Fulfillment
Store.Digital
ProductOption
VariantOptionSelection
InventoryReservation
ShippingRate
TaxShippingEvaluator
DownloadGrant
```


Executable validator: `tools/validate_planning_pack.py`.
