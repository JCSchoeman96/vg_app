# 00. Project Seed Brief

## Project
Voelgoed Digital Ecosystem.

## v0.2 planning target
v0.2 SHALL harden only the **Join Vriendinneklub** path.

## Product intent
Voelgoed needs a safe Ash 3.x / Phoenix / Elixir planning base for converting a public visitor into a registered, paying Vriendinneklub member with access grants that can be evaluated without guessing.

## Primary v0.2 business goal
A user can register, buy the Vriendinneklub membership offer, complete payment confirmation, receive an active membership, receive entitlement grants from locked benefit rules, and pass a read-only access evaluation.

## v0.2 actors
- `public_visitor`
- `registered_user`
- `staff_admin`
- `system`

## v0.2 domains in scope
- Accounts
- Memberships
- Catalog, limited to `Offer` and `Price` for Vriendinneklub only
- Commerce, limited to `Order`, `OrderItem`, `Payment`, and `PaymentEvent`

## v0.2 domains out of scope
The following domains SHALL NOT be implemented in v0.2:

- Events
- Learning
- Competitions
- Media
- Community
- full Content gating
- Access/check-in
- Reporting projections
- Notifications beyond declared post-commit placeholders

## v0.2 hard rules
- `Offer` and `Price` MUST support only Vriendinneklub membership purchase in v0.2.
- v0.2 MUST NOT implement a generic catalog abstraction.
- v0.2 MUST NOT implement a vague generic `Entitlement` resource.
- v0.2 SHALL use `BenefitRule`, `EntitlementGrant`, and `Memberships.evaluate_entitlement_access`.
- `OrderItem` MUST snapshot price at order creation.
- `PaymentEvent` MUST have a deterministic idempotency key.
- Payment logic MUST NOT directly create entitlement grants.
- Membership logic MUST NOT mutate payment state.
- Refund implementation SHALL be deferred, but future refund reversal implications MUST be captured as binding design constraints.
