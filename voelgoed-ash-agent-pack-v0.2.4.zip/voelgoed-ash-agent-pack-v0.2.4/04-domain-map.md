# 04. Domain Map

## v0.2 active write-domains

### Accounts
Owns user identity state.

Resources in v0.2:
- `User`

Accounts MUST NOT own membership lifecycle, order totals, payment state, benefit rules, or entitlement grants.

### Memberships
Owns Vriendinneklub plan, membership lifecycle, benefit rules, entitlement grants, and access evaluation.

Resources in v0.2:
- `MembershipPlan`
- `Membership`
- `BenefitRule`
- `EntitlementGrant`

Memberships MUST NOT capture payment, mutate payment state, or calculate order totals.

### Catalog
Owns the minimal commercial definition of the Vriendinneklub membership offer and price.

Resources in v0.2:
- `Offer`
- `Price`

Catalog MUST NOT become a generic product/course/event catalog in v0.2.

### Commerce
Owns order lifecycle, order item price snapshots, payment state, and payment events.

Resources in v0.2:
- `Order`
- `OrderItem`
- `Payment`
- `PaymentEvent`

Commerce MUST NOT create entitlement grants directly.

## v0.2 support concerns

### Notifications
Notifications are side effects only. They MUST NOT own business truth.

### Reporting
Reporting is out of scope for v0.2. Reporting MUST NOT create write-domain resources.

### Admin
Admin is an interface over domain actions. Admin MUST NOT be modelled as a business domain.

## Deferred domains
The following domains SHALL remain deferred until their workflows receive a separate grill-me pass:

- Taxonomy
- Content
- Learning
- Events
- Access / Admissions
- Media
- Community
- Partnerships
- Competitions
- Audience

## Binding v0.2 source-of-truth rules
- User identity truth SHALL live in `Accounts.User`.
- Membership status truth SHALL live in `Memberships.Membership`.
- Benefit definition truth SHALL live in `Memberships.BenefitRule`.
- Access grant truth SHALL live in `Memberships.EntitlementGrant`.
- Purchase offer truth SHALL live in `Catalog.Offer`.
- Price truth SHALL live in `Catalog.Price` before purchase and `Commerce.OrderItem` after snapshot.
- Order truth SHALL live in `Commerce.Order`.
- Payment truth SHALL live in `Commerce.Payment` and `Commerce.PaymentEvent`.
