# VS-002D — Activate Membership and Grants

## Status
READY_FOR_REVIEW_CLEAN

`READY_FOR_REVIEW` does not mean `READY_FOR_CODING`.

No coding agent SHALL implement this slice until the planning validator exists and passes.

## Goal
VS-002D starts from an already-paid Vriendinneklub order, activates the pending membership, and creates entitlement grants from active benefit rules exactly once.

## Non-goals
- Do not evaluate content, learning, event, ticket, or digital download access.
- Do not implement refunds.
- Do not implement recurring billing.
- Do not allow manual admin activation.
- Do not introduce a generic Entitlement resource.


## Slice boundary

VS-002D SHALL start from an already-paid order.

VS-002D SHALL activate membership through `Memberships.activate_membership`.

VS-002D SHALL create grants through `Memberships.create_entitlement_grants`.

VS-002D MUST NOT mark payment succeeded.

VS-002D MUST NOT mark order paid.

## Actors
- `system`

## Resources involved
- `Order`
- `Membership`
- `BenefitRule`
- `EntitlementGrant`

## Actions involved
- `Memberships.activate_membership`
- `Memberships.create_entitlement_grants`

## Blocking decisions
- none

## State transitions
- `Membership: pending_payment -> active`
- `EntitlementGrant: null -> active`

## Invariants
- VS-002D SHALL start from an already-paid order.
- VS-002D SHALL own membership activation.
- VS-002D SHALL own entitlement grant creation.
- VS-002D MUST NOT mark payment succeeded.
- VS-002D MUST NOT mark order paid.
- Membership MUST NOT activate without paid order.
- Active membership MUST reference source order.
- EntitlementGrant MUST reference source membership.
- EntitlementGrant MUST reference source BenefitRule.
- Duplicate activation MUST NOT duplicate grants.
- Future refund reversal MUST be able to identify source order/membership/rule.

## Files likely touched
- `lib/vg_app/memberships/membership.ex`
- `lib/vg_app/memberships/benefit_rule.ex`
- `lib/vg_app/memberships/entitlement_grant.ex`
- `lib/vg_app/memberships.ex`
- `test/vg_app/memberships/`

## Files forbidden
- `lib/vg_app/events/`
- `lib/vg_app/learning/`
- `lib/vg_app/competitions/`
- `lib/vg_app/content/`
- `refund implementation modules`
- `generic entitlement engine modules`

## Tests required
- `paid_order_activates_membership`
- `paid_order_activates_membership_once`
- `unpaid_order_cannot_activate_membership`
- `duplicate_activation_is_safe`
- `duplicate_activation_does_not_duplicate_grants`
- `active_membership_creates_expected_grants_once`
- `duplicate_grant_creation_is_idempotent`
- `archived_benefit_rule_does_not_create_grants`
- `benefit_rule_creates_expected_grants`
- `pending_membership_fails_access_evaluation`

## Validation commands
- `mix test test/vg_app/memberships`
- `mix format --check-formatted`

## Stop conditions
- Stop if generic Entitlement is needed.
- Stop if refund reversal cannot identify source membership/grants.
- Stop if access evaluation needs content, course, event, or ticket resources.

---

## Store_Blueprint alignment note

Store EntitlementGrant MAY inform persisted grant shape, but BenefitRule SHALL be the VG App source rule. Membership activation SHALL occur only after trusted payment success. Payment code MUST NOT create grants directly.
