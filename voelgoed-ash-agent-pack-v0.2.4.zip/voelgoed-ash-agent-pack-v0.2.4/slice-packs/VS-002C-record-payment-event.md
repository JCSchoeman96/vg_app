# VS-002C — Record Payment Event

## Status
READY_FOR_REVIEW_CLEAN

`READY_FOR_REVIEW` does not mean `READY_FOR_CODING`.

No coding agent SHALL implement this slice until the planning validator exists and passes.

## Goal
The system records a trusted payment event idempotently, marks payment succeeded, and marks order paid. VS-002C SHALL end with Order.state == paid and MUST NOT activate membership or create entitlement grants.

## Non-goals
- Do not implement provider-specific gateway SDKs.
- Do not activate membership directly from PaymentEvent.
- Do not create entitlement grants.
- Do not implement refunds.


## Slice boundary

VS-002C SHALL record trusted payment success and mark the order paid.

VS-002C MUST NOT activate membership.

VS-002C MUST NOT create entitlement grants.

VS-002C MUST stop when `Order.state == paid`.

## Actors
- `system`

## Resources involved
- `Order`
- `Payment`
- `PaymentEvent`

## Actions involved
- `Commerce.record_payment_event`
- `Commerce.mark_payment_succeeded`
- `Commerce.mark_order_paid`

## Blocking decisions
- none

## State transitions
- `PaymentEvent: null -> received -> accepted`
- `Payment: pending -> succeeded`
- `Order: pending_payment -> paid`

## Invariants
- VS-002C SHALL end with `Order.state == paid`.
- VS-002C MUST NOT activate membership.
- VS-002C MUST NOT create entitlement grants.
- PaymentEvent MUST own idempotency.
- Duplicate PaymentEvent MUST NOT create a second row.
- Payment return/cancel SHALL be read-only.
- Payment amount MUST match order total before payment succeeds.
- Payment code MUST NOT create grants.

## Files likely touched
- `lib/vg_app/commerce/payment_event.ex`
- `lib/vg_app/commerce/payment.ex`
- `lib/vg_app/commerce/order.ex`
- `lib/vg_app/commerce.ex`
- `test/vg_app/commerce/`

## Files forbidden
- `lib/vg_app/memberships/entitlement_grant.ex`
- `lib/vg_app/events/`
- `lib/vg_app/learning/`
- `refund modules`
- `generic fulfilment modules`

## Tests required
- `records_payment_event_once`
- `duplicate_payment_event_does_not_create_second_row`
- `duplicate_payment_event_is_ignored`
- `payment_event_does_not_activate_membership`
- `payment_return_cancel_is_read_only`
- `payment_code_does_not_create_entitlement_grants`
- `successful_event_marks_payment_succeeded`
- `amount_mismatch_rejected`
- `amount_mismatch_blocks_order_paid`
- `succeeded_payment_marks_order_paid`
- `duplicate_mark_order_paid_does_not_duplicate_activation`
- `duplicate_success_event_does_not_duplicate_success_effects`
- `failed_payment_does_not_activate_membership`

## Validation commands
- `mix test test/vg_app/commerce`
- `mix format --check-formatted`

## Stop conditions
- Stop if payment provider identity is unclear.
- Stop if return/cancel tries to mark payment succeeded.
- Stop if implementation needs refund state.

---

## Store_Blueprint alignment note

Store ProviderEvent/WebhookReceipt patterns MAY inform trusted payment-event ingestion. PaymentEvent SHALL be the idempotency source. Payment return/cancel SHALL be read-only.
