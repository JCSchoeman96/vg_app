# VS-002B — Create Pending Join Order

## Status
READY_FOR_REVIEW_CLEAN

`READY_FOR_REVIEW` does not mean `READY_FOR_CODING`.

No coding agent SHALL implement this slice until the planning validator exists and passes.

## Goal
A registered user creates or reuses a pending Vriendinneklub join order with one immutable OrderItem price snapshot and a pending membership.

## Non-goals
- Do not mark payment as succeeded.
- Do not activate membership.
- Do not create entitlement grants.
- Do not add cart-first checkout.
- Do not add refunds, discounts, bundles, shipping, or tax.

## Actors
- `registered_user`
- `system`

## Resources involved
- `User`
- `Offer`
- `Price`
- `Order`
- `OrderItem`
- `Payment`
- `Membership`

## Actions involved
- `Commerce.create_pending_order`
- `Commerce.add_vriendinneklub_order_item`
- `Catalog.snapshot_price_for_order_item`
- `Commerce.submit_order_for_payment`
- `Memberships.create_pending_membership`

## Blocking decisions
- none

## State transitions
- `Order: null -> pending_payment`
- `OrderItem: null -> active`
- `Payment: null -> pending`
- `Membership: null -> pending_payment`

## Invariants
- Order MUST belong to a registered active user.
- A registered user SHALL have at most one active pending join order per MembershipPlan.
- OrderItem quantity MUST be 1.
- OrderItem MUST snapshot price at creation.
- Pending membership MUST NOT grant access.

## Files likely touched
- `lib/vg_app/commerce/order.ex`
- `lib/vg_app/commerce/order_item.ex`
- `lib/vg_app/commerce/payment.ex`
- `lib/vg_app/catalog/price.ex`
- `lib/vg_app/memberships/membership.ex`
- `test/vg_app/commerce/`
- `test/vg_app/memberships/`

## Files forbidden
- `lib/vg_app/events/`
- `lib/vg_app/learning/`
- `lib/vg_app/competitions/`
- `refund modules`
- `discount/coupon modules`
- `bundle modules`
- `shipping/tax modules`
- `cart modules`

## Tests required
- `active_user_can_create_pending_join_order`
- `suspended_user_cannot_create_pending_join_order`
- `adds_vriendinneklub_item_with_price_snapshot`
- `order_item_snapshots_price_at_creation`
- `paid_order_item_snapshot_is_immutable`
- `rejects_quantity_above_one_in_v0_2`
- `rejects_duplicate_vriendinneklub_item_for_order`
- `submit_order_creates_pending_payment`
- `submit_order_moves_order_to_pending_payment`
- `submit_order_does_not_activate_membership`
- `creates_pending_membership_for_join_order`
- `pending_membership_does_not_grant_access`
- `snapshot_contains_amount_currency_and_price_source`
- `snapshot_does_not_mutate_price`

## Validation commands
- `mix test test/vg_app/commerce test/vg_app/memberships`
- `mix format --check-formatted`

## Stop conditions
- Stop if implementation requires refunds, discounts, bundles, shipping, tax, or cart-first checkout.
- Stop if pending order reuse cannot be enforced deterministically.

---

## Store_Blueprint alignment note

Store order and line-item snapshot patterns MAY inform this slice. Cart-first checkout, product variants, inventory, shipping, tax, coupons, and full checkout draft machinery MUST NOT be inherited.
