# VS-002E — Evaluate Member Access

## Status
READY_FOR_REVIEW_CLEAN

`READY_FOR_REVIEW` does not mean `READY_FOR_CODING`.

No coding agent SHALL implement this slice until the planning validator exists and passes.

## Goal
The system evaluates whether an active member has access from existing EntitlementGrant records.

## Non-goals
- Do not create memberships.
- Do not activate memberships.
- Do not create entitlement grants.
- Do not mutate order, payment, membership, or grant state.
- Do not add content, learning, events, or digital downloads.

## Actors
- `registered_user`
- `system`

## Resources involved
- `User`
- `Membership`
- `BenefitRule`
- `EntitlementGrant`

## Actions involved
- `Memberships.evaluate_entitlement_access`

## Blocking decisions
- none

## State transitions
- `Memberships.evaluate_entitlement_access: read-only, no state change`

## Invariants
- Access evaluation MUST NOT mutate state.
- Active grant allows access.
- Revoked grant denies access.
- Expired grant denies access.
- Wrong-user grant is denied.

## Files likely touched
- `lib/vg_app/memberships/entitlement_grant.ex`
- `lib/vg_app/memberships.ex`
- `test/vg_app/memberships/evaluate_entitlement_access_test.exs`

## Files forbidden
- `lib/vg_app/events/`
- `lib/vg_app/learning/`
- `lib/vg_app/content/`
- `lib/vg_app/digital/`
- `lib/vg_app/commerce/payment.ex`

## Tests required
- `active_grant_allows_access`
- `revoked_grant_denies_access`
- `expired_grant_denies_access`
- `wrong_user_grant_denied`
- `access_evaluation_does_not_mutate_state`

## Validation commands
- `mix test test/vg_app/memberships/evaluate_entitlement_access_test.exs`
- `mix format --check-formatted`

## Stop conditions
- Stop if access evaluation requires Content, Learning, Events, or Digital Downloads.
- Stop if the action mutates state.

---

## Store_Blueprint alignment note

Store entitlement-aware access patterns MAY inform read-side checks only. This action MUST NOT mutate state and MUST NOT depend on Digital Downloads, Content, Learning, or Events.
