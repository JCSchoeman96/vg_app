# VS-001A — Register Account

## Status
READY_FOR_REVIEW_CLEAN

`READY_FOR_REVIEW` does not mean `READY_FOR_CODING`.

No coding agent SHALL implement this slice until the planning validator exists and passes.

## Goal
A public visitor registers a VG App account and becomes an active registered user.

## Non-goals
- Do not create memberships.
- Do not create orders.
- Do not submit payment.
- Do not create entitlement grants.

## Actors
- `public_visitor`

## Resources involved
- `User`

## Actions involved
- `Accounts.register_user`

## Blocking decisions
- none

## State transitions
- `User: null -> active`

## Invariants
- Email MUST be unique.
- Registration MUST NOT create membership/order/payment records.
- Suspended users MUST NOT start protected v0.2 flows.

## Files likely touched
- `lib/vg_app/accounts/user.ex`
- `lib/vg_app/accounts.ex`
- `lib/vg_app_web/`
- `test/vg_app/accounts/`

## Files forbidden
- `lib/vg_app/memberships/`
- `lib/vg_app/commerce/`
- `lib/vg_app/catalog/`
- `lib/vg_app/events/`
- `lib/vg_app/learning/`

## Tests required
- `registers_user_with_unique_email`
- `rejects_duplicate_email`
- `does_not_create_membership`
- `suspended_user_cannot_start_join_flow`

## Validation commands
- `mix test test/vg_app/accounts`
- `mix format --check-formatted`

## Stop conditions
- Stop if registration tries to create membership automatically.
- Stop if checkout is embedded into registration.

---

## Store_Blueprint alignment note

Store Accounts MAY inform account/auth patterns. Store admin/support role assumptions MUST NOT be copied without actor-matrix approval.
