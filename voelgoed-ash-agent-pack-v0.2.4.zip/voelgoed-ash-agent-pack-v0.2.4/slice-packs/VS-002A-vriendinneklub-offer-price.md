# VS-002A — Vriendinneklub Offer and Price

## Status
READY_FOR_REVIEW_CLEAN

`READY_FOR_REVIEW` does not mean `READY_FOR_CODING`.

No coding agent SHALL implement this slice until the planning validator exists and passes.

## Goal
A staff admin defines an active Vriendinneklub MembershipPlan, BenefitRule, Offer, and Price.

## Non-goals
- Do not register users.
- Do not create orders.
- Do not process payment.
- Do not create entitlement grants.
- Do not add generic catalog, products, variants, inventory, coupons, shipping, or tax.

## Actors
- `staff_admin`

## Resources involved
- `MembershipPlan`
- `BenefitRule`
- `Offer`
- `Price`

## Actions involved
- `Memberships.create_membership_plan`
- `Memberships.create_benefit_rule`
- `Memberships.activate_benefit_rule`
- `Memberships.activate_membership_plan`
- `Catalog.create_vriendinneklub_offer`
- `Catalog.create_vriendinneklub_price`
- `Catalog.activate_vriendinneklub_price`
- `Catalog.activate_vriendinneklub_offer`

## Blocking decisions
- none

## State transitions
- `MembershipPlan: null -> draft -> active`
- `BenefitRule: null -> draft -> active`
- `Offer: null -> draft -> active`
- `Price: null -> draft -> active`

## Invariants
- VS-002A production actor SHALL be staff_admin.
- System seeding MAY be used only as test fixture setup.
- An active offer MUST have exactly one active price.
- A BenefitRule MUST belong to a MembershipPlan.

## Files likely touched
- `lib/vg_app/memberships/membership_plan.ex`
- `lib/vg_app/memberships/benefit_rule.ex`
- `lib/vg_app/catalog/offer.ex`
- `lib/vg_app/catalog/price.ex`
- `test/vg_app/memberships/`
- `test/vg_app/catalog/`

## Files forbidden
- `lib/vg_app/commerce/`
- `lib/vg_app/events/`
- `lib/vg_app/learning/`
- `lib/vg_app/shipping/`
- `lib/vg_app/tax/`

## Tests required
- `staff_admin_can_create_plan`
- `active_plan_requires_benefit_rule`
- `duplicate_plan_code_rejected`
- `creates_draft_benefit_rule`
- `rejects_out_of_scope_benefit_type`
- `reject_duplicate_rule_code_per_plan`
- `creates_vriendinneklub_offer_for_membership_plan`
- `rejects_non_membership_offer_type_in_v0_2`
- `rejects_duplicate_offer_code`
- `creates_draft_price_for_vriendinneklub_offer`
- `active_price_requires_positive_amount`
- `activates_single_price_per_offer`
- `rejects_second_active_price`
- `active_offer_requires_one_active_price`

## Validation commands
- `mix test test/vg_app/memberships test/vg_app/catalog`
- `mix format --check-formatted`

## Stop conditions
- Stop if implementation needs generic catalog polymorphism.
- Stop if implementation introduces product variants, inventory, shipping, tax, coupons, or promotions.

---

## Store_Blueprint alignment note

Store Catalog/Pricing MAY inform deterministic pricing and snapshot discipline only. Product, Variant, Inventory, coupons, promotions, shipping, and tax MUST NOT become v0.2 implementation dependencies.
