# 10. Agent Context Pack Template

This template defines what a future generated agent context pack MUST contain.

## Project identity

```yaml
project_identity:
  display_name: VG App
  root_module: VGApp
  otp_app: :vg_app
  repo_module: VGApp.Repo
  web_module: VGAppWeb
  endpoint_module: VGAppWeb.Endpoint
  github_repo: vg_app
  app_folder: vg_app
```

## Store_Blueprint reference

```yaml
store_blueprint_reference:
  authority: reference_only
  decision_file: references/STORE_BLUEPRINT_EXTRACTION_DECISION_V1.md
  module_copy_rule: KEEP_RENAME_REWRITE_REJECT_required
```

No Store_Blueprint module may be copied from this context pack.

Store_Blueprint may inform patterns only.

## Required fields per generated slice context

```yaml-example
slice_id: VS-000X
goal: string
non_goals: []
resources_involved: []
actions_involved: []
actor_assumptions: []
state_transitions: []
side_effect_boundaries: []
invariants: []
files_likely_touched: []
files_forbidden: []
tests_required: []
validation_commands: []
stop_conditions: []
store_blueprint_reference_notes: []
readiness_status: READY_FOR_REVIEW | READY_FOR_CODING | NOT_READY
```

## Hard rules

- Generated context MUST NOT include future-domain brainstorming.
- Generated context MUST NOT include Store_Blueprint code.
- Generated context MUST include only the slice-relevant resources/actions/tests.
- Generated context MUST fail closed if any referenced resource/action/test is missing.
