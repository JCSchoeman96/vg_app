# 08. Slice Matrix

## v0.2 rule
Only the slices in this file are in scope for v0.2.

`READY_FOR_REVIEW` does not mean `READY_FOR_CODING`.

No slice SHALL be marked `READY_FOR_CODING` until the planning validator exists and passes.

## Revised v0.2.4 slice matrix

| Slice | Goal | Resources | Actions | Status |
|---|---|---|---|---|
| VS-001A | Visitor registers account | User | `Accounts.register_user` | READY_FOR_REVIEW_CLEAN |
| VS-002A | Staff admin defines active Vriendinneklub plan, benefit rule, offer, and price | MembershipPlan, BenefitRule, Offer, Price | `Memberships.create_membership_plan`, `Memberships.create_benefit_rule`, `Memberships.activate_benefit_rule`, `Memberships.activate_membership_plan`, `Catalog.create_vriendinneklub_offer`, `Catalog.create_vriendinneklub_price`, `Catalog.activate_vriendinneklub_price`, `Catalog.activate_vriendinneklub_offer` | READY_FOR_REVIEW_CLEAN |
| VS-002B | Registered user creates pending join order with immutable price snapshot and pending membership | User, Offer, Price, Order, OrderItem, Payment, Membership | `Commerce.create_pending_order`, `Commerce.add_vriendinneklub_order_item`, `Catalog.snapshot_price_for_order_item`, `Commerce.submit_order_for_payment`, `Memberships.create_pending_membership` | READY_FOR_REVIEW_CLEAN |
| VS-002C | System records payment event idempotently and marks payment/order paid | Order, Payment, PaymentEvent | `Commerce.record_payment_event`, `Commerce.mark_payment_succeeded`, `Commerce.mark_order_paid` | READY_FOR_REVIEW_CLEAN |
| VS-002D | Paid order activates membership and creates entitlement grants | Order, Membership, BenefitRule, EntitlementGrant | `Memberships.activate_membership`, `Memberships.create_entitlement_grants` | READY_FOR_REVIEW_CLEAN |
| VS-002E | System evaluates member access from entitlement grants | User, Membership, BenefitRule, EntitlementGrant | `Memberships.evaluate_entitlement_access` | READY_FOR_REVIEW_CLEAN |

## Deferred slice rows
The original broad future slices for Events, Learning, Competitions, Media, Community, bundles, coupon stacking, and refunds are removed from the v0.2 matrix.

They SHALL NOT be reintroduced until each receives its own domain/risk-area grill and approved slice pack.

## Store_Blueprint alignment

Store_Blueprint SHALL be a reference/extraction source only.

No slice SHALL copy Store_Blueprint modules without a focused `KEEP / RENAME / REWRITE / REJECT` extraction decision.

The slice matrix MUST NOT add Events, Learning, Competitions, Media, Community, Shipping, Tax, FulfilmentDispatch, AuditEvent, generic Catalog, product variants, inventory, digital downloads, or cart-first checkout in v0.2.4.


## v0.2.4 readiness rule

READY_FOR_REVIEW_CLEAN does not mean READY_FOR_CODING. No slice SHALL be marked READY_FOR_CODING until the executable validator passes and the slice passes a vertical-slice execution grill.
