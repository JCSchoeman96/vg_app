# 15. Planning Validator Rules

## Purpose
These rules define the planning checks that MUST pass before a slice can be marked `READY_FOR_CODING`.

## Status language

- `READY_FOR_REVIEW` means the planning artifact is coherent enough for human/agent review.
- `READY_FOR_REVIEW_CLEAN` means the v0.2.4 mechanical checks have been applied, but no executable validator has passed yet.
- `READY_FOR_CODING` means the planning validator exists, passes, and the slice can be handed to a coding agent.
- No v0.2.4 slice SHALL be marked `READY_FOR_CODING` until all machine-readable YAML parses, the planning validator exists, and the validator passes.

## Validator rules
The planning validator MUST fail if any of the following are true:

1. `planning-pack.yml` does not exist.
2. A slice references a resource without a resource card in `05-resource-cards.md`.
3. A slice references an action without an action card in `06-action-cards.md`.
4. A slice marked `READY_FOR_CODING` contains any unresolved `OPEN DECISION`.
5. A locked decision appears in `blocking_decisions`.
6. A resource card lacks source-of-truth ownership.
7. A resource card lacks tenant/ownership scope.
8. A resource card lacks tests required.
9. An action card lacks actor, trigger, preconditions, state changes, side effects, transaction boundary, idempotency, authorization, audit requirement, forbidden behaviours, tests required, or open decisions.
10. A payment, order, membership activation, or grant-creation action lacks idempotency.
11. A payment action directly creates entitlement grants.
12. A membership action directly mutates payment state.
13. `Offer` or `Price` claims generic catalog behaviour in v0.2.
14. Any v0.2 slice references Events, Learning, Competitions, Media, Community, bundles, coupon stacking, full refunds, event tickets, organiser portal, or generic catalog expansion as required implementation dependencies.
15. `OrderItem` lacks a price snapshot rule.
16. `PaymentEvent` lacks a unique idempotency key.
17. `EntitlementGrant` lacks a source `BenefitRule`.
18. `EntitlementGrant` lacks a source `Membership`.
19. `Memberships.evaluate_entitlement_access` mutates state.
20. A slice uses vague tests such as `commerce tests`, `membership tests`, or `entitlement tests` instead of exact test names.
21. A side effect is declared without a transaction boundary.
22. A slice pack lists files outside its allowed domain scope without an explicit reason.
23. Any planning file contains legacy placeholder namespace after D-016 is locked.
24. Any active v0.2 resource action appears under `actions_deferred` only.
25. Any `actions_deferred` action is required by a v0.2 slice.
26. Any empty YAML list field intended as a list is null instead of `[]`.
27. Any example YAML block parses as a real resource or action card.
28. `Order` contains `failed` or `payment_failed` as an active v0.2 state.
29. Payment failure is modelled as an order failure in v0.2.
30. `Price` uses vague money fields instead of `amount_minor` and `currency`.
31. A test listed in a resource/action card is absent from `14-test-matrix.yml`.
32. Invalid YAML in any machine-readable block appears in resource cards, action cards, slice packs, state maps, test matrices, or `planning-pack.yml`.
33. Duplicate semantic test names with different spelling appear across the pack.

## v0.2 forbidden references
The validator MUST fail if these strings appear in active v0.2 slice resources/actions as required implementation dependencies:

```text
Event
Ticket
TicketType
CheckIn
ScanLog
Course
Enrollment
ContentItem
Competition
Vote
Media
Community
Bundle
Coupon
Refund
DiscountRule
GenericEntitlement
FulfilmentDispatch
AuditEvent
ProductVariant
Inventory
CartFirstCheckout
DigitalDownload
Subscription
Shipping
Tax
```

## Store_Blueprint alignment validator rules

| Rule ID | Rule |
|---|---|
| VR-SB-001 | The pack MUST contain `references/STORE_BLUEPRINT_EXTRACTION_DECISION_V1.md`. |
| VR-SB-002 | `README.md` MUST state that Store_Blueprint is a reference/extraction source only. |
| VR-SB-003 | A Store_Blueprint module MUST NOT be copied or authorized without a focused `KEEP / RENAME / REWRITE / REJECT` extraction decision. |
| VR-SB-004 | A v0.2 resource card influenced by Store_Blueprint MUST include `Store_Blueprint reference notes`. |
| VR-SB-005 | A v0.2 resource/action/slice MUST NOT reference Store Product, Variant, Inventory, Shipping, Tax, Fulfillment, Digital Downloads, or cart-first checkout as required implementation dependencies. |
| VR-SB-006 | `PaymentEvent` MUST be the idempotency source for payment events. |
| VR-SB-007 | Payment return/cancel handlers MUST be explicitly read-only. |
| VR-SB-008 | Membership activation MUST require trusted payment success. |
| VR-SB-009 | `BenefitRule` MUST be the source rule for `EntitlementGrant` creation. |
| VR-SB-010 | No slice SHALL be marked `READY_FOR_CODING` until the validator passes. |
| VR-SB-011 | No resource/action/slice card SHALL contain legacy placeholder namespaces after D-016 is locked. |

## Namespace validator rules

| Rule ID | Rule |
|---|---|
| VR-NS-001 | No planning file SHALL contain legacy placeholder namespaces after D-016 is LOCKED. |
| VR-NS-002 | Resource cards MUST use `VGApp.*` modules. |
| VR-NS-003 | Web-facing references MUST use `VGAppWeb.*`. |
| VR-NS-004 | Repo references MUST use `VGApp.Repo`. |
| VR-NS-005 | OTP app references MUST use `:vg_app`. |


## YAML validity validator rules

| Rule ID | Rule |
|---|---|
| VR-YAML-001 | All fenced YAML blocks in resource cards, action cards, slice packs, state maps, test matrices, and `planning-pack.yml` MUST parse as valid YAML. Invalid YAML SHALL block `READY_FOR_CODING`. |

## Test coverage validator rules

| Rule ID | Rule |
|---|---|
| VR-TEST-001 | Every `tests_required` entry in `05-resource-cards.md` and `06-action-cards.md` MUST appear in `14-test-matrix.yml`. |
| VR-TEST-002 | Test names MUST use one canonical spelling across resource cards, action cards, slice packs, and test matrix. Duplicate semantic test names with different spelling SHALL fail validation. |

## Basic planning validator spec

The detailed validator contract is in:

- `tools/planning_validator_spec.md`


## v0.2.4 Orchestration and Readiness Rules

### VR-ORCH-001
Commerce.mark_order_paid SHALL NOT create Membership or EntitlementGrant records.

### VR-ORCH-002
VS-002C SHALL end with Order.state == paid.

### VR-ORCH-003
VS-002D SHALL own membership activation and entitlement grant creation.

### VR-ACTION-001
Cross-resource action cards MUST declare primary_resource and mutates_resources.

### VR-READY-001
READY_FOR_REVIEW_CLEAN SHALL NOT imply READY_FOR_CODING.

### VR-READY-002
No slice SHALL be READY_FOR_CODING until the executable planning validator exists and passes.


Executable validator: `tools/validate_planning_pack.py`.
