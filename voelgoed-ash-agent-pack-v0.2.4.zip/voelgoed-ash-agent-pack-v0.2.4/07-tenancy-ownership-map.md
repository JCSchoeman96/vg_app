# 07. Tenancy / Ownership Map

## v0.2 ownership rule
v0.2 SHALL be platform-owned only.

No organiser-scoped tenancy SHALL be introduced in v0.2.

## v0.2 ownership map

| Area | Owner model | Binding rule |
|---|---|---|
| Accounts | Platform-owned | User identity is global. |
| Memberships | Platform-owned | Vriendinneklub plans, memberships, benefit rules, and grants are platform-owned. |
| Catalog | Platform-owned | Offer and Price are limited to Vriendinneklub membership purchase. |
| Commerce | Platform-owned with user-scoped records | Orders, order items, payments, and payment events belong to a user but are platform-owned business truth. |
| Admin | Interface only | Admin MUST call domain actions and MUST NOT own business truth. |
| Notifications | Side-effect concern | Notifications MUST NOT own business truth. |
| Reporting | Deferred | Reporting MUST NOT create v0.2 write resources. |

## v0.2 tenant scope vocabulary

| Scope | Meaning | Allowed in v0.2 |
|---|---|---|
| global | Platform-wide record | Yes |
| user_scoped | Owned by or attached to one user | Yes |
| organiser_scoped | Owned by event organiser/partner | No |
| multi_tenant | App-wide tenant model | No |

## Guardrails
- v0.2 MUST NOT add app-wide tenancy.
- v0.2 MUST NOT add organiser-scoped resources.
- v0.2 MUST NOT add event ownership or partner access rules.
- Future organiser tenancy MUST receive a separate grill-me pass before implementation.
